-- ============================================================
-- Maritime Cruise Agency — Migration 6
-- Adds `email` to profiles (copied from auth.users at sign-up) so
-- server actions can send notification emails without needing the
-- Supabase admin API or a service-role key.
-- ============================================================

alter table profiles add column if not exists email text;

-- Backfill existing profiles from auth.users, since the trigger only
-- populates new sign-ups going forward.
update profiles p
set email = u.email
from auth.users u
where p.id = u.id and p.email is null;

create or replace function handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (
    id, email, first_name, last_name, full_name, phone,
    country_of_residence, nationality, phone_country_code, phone_number,
    date_of_birth, gender, referral_source
  )
  values (
    new.id,
    new.email,
    new.raw_user_meta_data->>'first_name',
    new.raw_user_meta_data->>'last_name',
    trim(concat(new.raw_user_meta_data->>'first_name', ' ', new.raw_user_meta_data->>'last_name')),
    nullif(concat(new.raw_user_meta_data->>'phone_country_code', ' ', new.raw_user_meta_data->>'phone_number'), ' '),
    new.raw_user_meta_data->>'country_of_residence',
    new.raw_user_meta_data->>'nationality',
    new.raw_user_meta_data->>'phone_country_code',
    new.raw_user_meta_data->>'phone_number',
    nullif(new.raw_user_meta_data->>'date_of_birth', '')::date,
    new.raw_user_meta_data->>'gender',
    new.raw_user_meta_data->>'referral_source'
  );
  return new;
end;
$$ language plpgsql security definer;
