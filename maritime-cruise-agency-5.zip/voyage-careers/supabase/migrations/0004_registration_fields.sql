-- ============================================================
-- Maritime Cruise Agency — Migration 4
-- Expands the registration form: first/last name, country of
-- residence, nationality, phone (country code + number), date of
-- birth, gender, and how the applicant heard about us.
--
-- `full_name` is kept and auto-populated from first_name + last_name
-- so every existing page that already reads profiles.full_name
-- keeps working unchanged.
-- ============================================================

alter table profiles add column if not exists first_name text;
alter table profiles add column if not exists last_name text;
alter table profiles add column if not exists country_of_residence text;
alter table profiles add column if not exists nationality text;
alter table profiles add column if not exists phone_country_code text;
alter table profiles add column if not exists phone_number text;
alter table profiles add column if not exists date_of_birth date;
alter table profiles add column if not exists gender text;
alter table profiles add column if not exists referral_source text;

-- Replace the signup trigger function to populate all of the above
-- from the metadata passed at sign-up time (see app/login/page.tsx).
create or replace function handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (
    id, first_name, last_name, full_name, phone,
    country_of_residence, nationality, phone_country_code, phone_number,
    date_of_birth, gender, referral_source
  )
  values (
    new.id,
    new.raw_user_meta_data->>'first_name',
    new.raw_user_meta_data->>'last_name',
    trim(concat(new.raw_user_meta_data->>'first_name', ' ', new.raw_user_meta_data->>'last_name')),
    nullif(concat(new.raw_user_meta_data->>'phone_country_code', ' ', new.raw_user_meta_data->>'phone_number'), ' '),
    new.raw_user_meta_data->>'country_of_residence',
    new.raw_user_meta_data->>'nationality',
    new.raw_user_meta_data->>'phone_country_code',
    new.raw_user_meta_data->>'phone_number',
    nullif(new.raw_user_meta_data->>'date_of_birth', '')::date,
    new.raw_user_meta_data->>'gender',
    new.raw_user_meta_data->>'referral_source'
  );
  return new;
end;
$$ language plpgsql security definer;
