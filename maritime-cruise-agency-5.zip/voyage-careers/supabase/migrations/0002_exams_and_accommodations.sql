-- ============================================================
-- Voyage Careers — Migration 2
-- Adds: exam PDFs (staff-uploaded, per category) and an
-- accommodation listings catalog (staff-posted, with photos)
-- linked into travel_requests, plus a 'pending' travel status.
--
-- Run this AFTER 0001_init.sql, in the Supabase SQL editor.
-- Note: run the ALTER TYPE statement (step 1) on its own first if
-- your Postgres version complains about using a new enum value in
-- the same transaction it was added in.
-- ============================================================

-- ------------------------------------------------------------
-- 1. New travel status: 'pending' — shown while an accommodation
--    hasn't been sourced yet, or while the applicant's documents
--    are still under review (accommodation isn't confirmed until
--    both a listing is assigned AND documents clear).
-- ------------------------------------------------------------
alter type travel_status add value if not exists 'pending';

-- ------------------------------------------------------------
-- 2. Exam documents — staff post the exam for a category as a PDF.
--    Applicants always see the most recent one per category.
-- ------------------------------------------------------------
create table exam_documents (
  id uuid primary key default gen_random_uuid(),
  category job_category not null,
  file_path text not null, -- path inside the 'exam-documents' storage bucket
  title text,
  uploaded_by uuid references profiles(id),
  created_at timestamptz not null default now()
);

alter table exam_documents enable row level security;

create policy "exam_documents: anyone signed in can read" on exam_documents
  for select using (auth.uid() is not null);
create policy "exam_documents: staff manage" on exam_documents
  for all using (auth_role() = 'staff');

insert into storage.buckets (id, name, public)
values ('exam-documents', 'exam-documents', false)
on conflict (id) do nothing;

create policy "exam-documents bucket: staff uploads"
  on storage.objects for insert
  with check (bucket_id = 'exam-documents' and auth_role() = 'staff');
create policy "exam-documents bucket: signed-in users read"
  on storage.objects for select
  using (bucket_id = 'exam-documents' and auth.uid() is not null);
create policy "exam-documents bucket: staff replace/delete"
  on storage.objects for update using (bucket_id = 'exam-documents' and auth_role() = 'staff');
create policy "exam-documents bucket: staff delete"
  on storage.objects for delete using (bucket_id = 'exam-documents' and auth_role() = 'staff');

-- ------------------------------------------------------------
-- 3. Accommodation listings — staff post available places to stay,
--    with photos, that applicants can browse and request.
-- ------------------------------------------------------------
create table accommodations (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  location text,
  description text,
  price_info text,
  photo_paths text[] not null default '{}', -- paths inside 'accommodation-photos' bucket
  is_available boolean not null default true,
  posted_by uuid references profiles(id),
  created_at timestamptz not null default now()
);

alter table accommodations enable row level security;

create policy "accommodations: anyone signed in can read" on accommodations
  for select using (auth.uid() is not null);
create policy "accommodations: staff manage" on accommodations
  for all using (auth_role() = 'staff');

-- Photos are pictures of bookable places, not sensitive documents,
-- so the bucket is public for simplicity (no signed URLs needed to
-- render a photo grid). Only staff can upload.
insert into storage.buckets (id, name, public)
values ('accommodation-photos', 'accommodation-photos', true)
on conflict (id) do nothing;

create policy "accommodation-photos bucket: staff uploads"
  on storage.objects for insert
  with check (bucket_id = 'accommodation-photos' and auth_role() = 'staff');
create policy "accommodation-photos bucket: public read"
  on storage.objects for select
  using (bucket_id = 'accommodation-photos');
create policy "accommodation-photos bucket: staff delete"
  on storage.objects for delete
  using (bucket_id = 'accommodation-photos' and auth_role() = 'staff');

-- ------------------------------------------------------------
-- 4. Link travel_requests to a specific accommodation listing.
--    Only meaningful when type = 'accommodation'.
-- ------------------------------------------------------------
alter table travel_requests
  add column if not exists accommodation_id uuid references accommodations(id);

-- New accommodation requests start life as 'pending' (rather than
-- 'requested') since the whole point of this status is "no place
-- found yet, or documents aren't cleared". Existing requests are
-- untouched by this migration.
alter table travel_requests alter column status set default 'requested';
