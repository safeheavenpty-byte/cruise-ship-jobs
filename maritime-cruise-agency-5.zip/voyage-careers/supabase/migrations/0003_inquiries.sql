-- ============================================================
-- Voyage Careers — Migration 3
-- Adds an in-platform inquiries/messaging system so applicants,
-- partners, and members of the public can consult with staff
-- WITHOUT going through WhatsApp — see the scam notice shown in
-- the app for why that matters.
-- ============================================================

create type inquiry_status as enum ('new', 'in_progress', 'resolved');

create table inquiries (
  id uuid primary key default gen_random_uuid(),
  -- null when submitted by a member of the public who isn't signed in
  sender_id uuid references profiles(id) on delete set null,
  name text not null,
  email text not null,
  phone text,
  message text not null,
  staff_reply text,
  status inquiry_status not null default 'new',
  handled_by uuid references profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table inquiries enable row level security;

create trigger inquiries_updated_at before update on inquiries
  for each row execute procedure set_updated_at();

-- Anyone can submit — including anonymous visitors on the public
-- /contact page. If they're signed in, sender_id must be their own id.
create policy "inquiries: anyone can submit" on inquiries
  for insert
  with check (sender_id is null or sender_id = auth.uid());

-- Senders see only their own thread; staff see and manage everything.
create policy "inquiries: sender reads own" on inquiries
  for select using (sender_id = auth.uid());
create policy "inquiries: staff read all" on inquiries
  for select using (auth_role() = 'staff');
create policy "inquiries: staff update" on inquiries
  for update using (auth_role() = 'staff');
