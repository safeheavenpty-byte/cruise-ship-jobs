-- ============================================================
-- Voyage Careers — Initial schema
-- Roles: applicant, staff, partner
-- Run this in the Supabase SQL editor, or via `supabase db push`
-- ============================================================

-- ------------------------------------------------------------
-- 1. Extension: uuid generation
-- ------------------------------------------------------------
create extension if not exists "pgcrypto";

-- ------------------------------------------------------------
-- 2. Profiles (extends Supabase auth.users with role + basic info)
-- ------------------------------------------------------------
create type user_role as enum ('applicant', 'staff', 'partner');

create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  role user_role not null default 'applicant',
  full_name text,
  phone text,
  -- only set for partner-role users: which agency/employer they belong to
  partner_company text,
  created_at timestamptz not null default now()
);

-- Auto-create a profile row whenever a new auth user signs up.
-- New signups default to 'applicant'; staff/partner accounts are
-- promoted manually by an admin (see README for how).
create function handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, full_name)
  values (new.id, new.raw_user_meta_data->>'full_name');
  return new;
end;
$$ language plpgsql security definer;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure handle_new_user();

-- ------------------------------------------------------------
-- 3. Jobs (posted by partners, visible to applicants + staff)
-- ------------------------------------------------------------
create type job_category as enum ('cruise', 'hospitality', 'healthcare');

create table jobs (
  id uuid primary key default gen_random_uuid(),
  partner_id uuid references profiles(id) on delete set null,
  category job_category not null,
  title text not null,
  line text, -- company / cruise line / hotel group name
  contract_length text,
  requirements text[] not null default '{}',
  is_open boolean not null default true,
  created_at timestamptz not null default now()
);

-- ------------------------------------------------------------
-- 4. Applications (applicant applying to a job)
-- ------------------------------------------------------------
create type application_stage as enum (
  'submitted', 'exam_pending', 'documents_pending',
  'under_review', 'approved', 'rejected'
);

create table applications (
  id uuid primary key default gen_random_uuid(),
  applicant_id uuid not null references profiles(id) on delete cascade,
  job_id uuid not null references jobs(id) on delete cascade,
  stage application_stage not null default 'submitted',
  reviewed_by uuid references profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (applicant_id, job_id)
);

-- ------------------------------------------------------------
-- 5. Exam results
-- ------------------------------------------------------------
create table exam_results (
  id uuid primary key default gen_random_uuid(),
  applicant_id uuid not null references profiles(id) on delete cascade,
  category job_category not null,
  score int not null check (score between 0 and 100),
  passed boolean not null,
  taken_at timestamptz not null default now()
);

-- ------------------------------------------------------------
-- 6. Documents (uploaded to Supabase Storage; row tracks status)
-- ------------------------------------------------------------
create type document_type as enum ('cv', 'police_clearance', 'medical_exam', 'certificate');
create type document_status as enum ('submitted', 'under_review', 'approved', 'rejected');

create table documents (
  id uuid primary key default gen_random_uuid(),
  applicant_id uuid not null references profiles(id) on delete cascade,
  type document_type not null,
  file_path text not null, -- path inside the 'documents' storage bucket
  status document_status not null default 'submitted',
  reviewed_by uuid references profiles(id),
  review_notes text,
  submitted_at timestamptz not null default now(),
  reviewed_at timestamptz
);

-- ------------------------------------------------------------
-- 7. Travel requests (visa / accommodation / flights)
-- `provider` lets manual tracking and future API integrations
-- share the same table without a later migration.
-- ------------------------------------------------------------
create type travel_type as enum ('visa', 'accommodation', 'flight');
create type travel_provider as enum ('manual', 'api');
create type travel_status as enum ('requested', 'in_progress', 'confirmed', 'declined');

create table travel_requests (
  id uuid primary key default gen_random_uuid(),
  applicant_id uuid not null references profiles(id) on delete cascade,
  application_id uuid references applications(id) on delete set null,
  type travel_type not null,
  provider travel_provider not null default 'manual',
  provider_ref text, -- external booking/visa reference once provider = 'api'
  status travel_status not null default 'requested',
  details jsonb not null default '{}', -- flexible: dates, destination, notes
  handled_by uuid references profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ------------------------------------------------------------
-- 8. updated_at helper trigger
-- ------------------------------------------------------------
create function set_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

create trigger applications_updated_at before update on applications
  for each row execute procedure set_updated_at();
create trigger travel_requests_updated_at before update on travel_requests
  for each row execute procedure set_updated_at();

-- ============================================================
-- ROW LEVEL SECURITY
-- ============================================================

alter table profiles enable row level security;
alter table jobs enable row level security;
alter table applications enable row level security;
alter table exam_results enable row level security;
alter table documents enable row level security;
alter table travel_requests enable row level security;

-- Helper: get the caller's role
create function auth_role() returns user_role as $$
  select role from profiles where id = auth.uid();
$$ language sql stable security definer;

-- ---------------- profiles ----------------
create policy "profiles: self read" on profiles
  for select using (id = auth.uid());
create policy "profiles: staff read all" on profiles
  for select using (auth_role() = 'staff');
create policy "profiles: self update" on profiles
  for update using (id = auth.uid());

-- ---------------- jobs ----------------
create policy "jobs: public read open jobs" on jobs
  for select using (is_open or auth_role() in ('staff', 'partner'));
create policy "jobs: partner manages own" on jobs
  for insert with check (auth_role() = 'partner' and partner_id = auth.uid());
create policy "jobs: partner updates own" on jobs
  for update using (auth_role() = 'partner' and partner_id = auth.uid());
create policy "jobs: staff manage all" on jobs
  for all using (auth_role() = 'staff');

-- ---------------- applications ----------------
create policy "applications: applicant sees own" on applications
  for select using (applicant_id = auth.uid());
create policy "applications: applicant creates own" on applications
  for insert with check (applicant_id = auth.uid());
create policy "applications: staff read/update all" on applications
  for all using (auth_role() = 'staff');
create policy "applications: partner sees applicants to their jobs" on applications
  for select using (
    auth_role() = 'partner'
    and job_id in (select id from jobs where partner_id = auth.uid())
  );

-- ---------------- exam_results ----------------
create policy "exam_results: applicant sees own" on exam_results
  for select using (applicant_id = auth.uid());
create policy "exam_results: applicant inserts own" on exam_results
  for insert with check (applicant_id = auth.uid());
create policy "exam_results: staff read all" on exam_results
  for select using (auth_role() = 'staff');

-- ---------------- documents ----------------
create policy "documents: applicant sees own" on documents
  for select using (applicant_id = auth.uid());
create policy "documents: applicant inserts own" on documents
  for insert with check (applicant_id = auth.uid());
create policy "documents: applicant updates own" on documents
  for update using (applicant_id = auth.uid()) with check (applicant_id = auth.uid());
create policy "documents: staff read/update all" on documents
  for all using (auth_role() = 'staff');

-- ---------------- travel_requests ----------------
create policy "travel: applicant sees own" on travel_requests
  for select using (applicant_id = auth.uid());
create policy "travel: applicant inserts own" on travel_requests
  for insert with check (applicant_id = auth.uid());
create policy "travel: staff read/update all" on travel_requests
  for all using (auth_role() = 'staff');

-- ============================================================
-- STORAGE (run once — creates the private documents bucket)
-- ============================================================
insert into storage.buckets (id, name, public)
values ('documents', 'documents', false)
on conflict (id) do nothing;

create policy "documents bucket: applicant uploads own folder"
  on storage.objects for insert
  with check (
    bucket_id = 'documents'
    and (storage.foldername(name))[1] = auth.uid()::text
  );

create policy "documents bucket: applicant reads own folder"
  on storage.objects for select
  using (
    bucket_id = 'documents'
    and (storage.foldername(name))[1] = auth.uid()::text
  );

create policy "documents bucket: staff reads all"
  on storage.objects for select
  using (bucket_id = 'documents' and auth_role() = 'staff');
