-- ============================================================
-- Maritime Cruise Agency — Migration 5
-- Adds:
--   1. A "language accreditation" document type (TOEFL/IELTS/TOEIC/
--      Cambridge/JLPT only), with a test_type column on documents.
--   2. A ships-under-management catalog, editable by staff.
--   3. A screening questionnaire (yes/no + two short-answer questions)
--      each applicant fills in once.
--   4. Employee number + ship number entry, which the applicant
--      submits themselves once HR issues them — this is enforced
--      through a SECURITY DEFINER function rather than a broad RLS
--      UPDATE policy, so an applicant can only ever move their own
--      application to 'approved' via this exact, narrow path (not by
--      writing to any other column on `applications`).
-- ============================================================

-- ------------------------------------------------------------
-- 1. Language accreditation documents
-- ------------------------------------------------------------
alter type document_type add value if not exists 'language_accreditation';

alter table documents add column if not exists test_type text;
-- Recognized test providers only — enforced at the application layer
-- (the upload form only offers these as options) and backstopped here.
alter table documents add constraint documents_test_type_check
  check (test_type is null or test_type in ('TOEFL', 'IELTS', 'TOEIC', 'Cambridge', 'JLPT'));

-- ------------------------------------------------------------
-- 2. Ships under management
-- ------------------------------------------------------------
create table ships (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  cruise_line text,
  notes text,
  is_active boolean not null default true,
  created_by uuid references profiles(id),
  created_at timestamptz not null default now()
);

alter table ships enable row level security;

create policy "ships: anyone signed in can read" on ships
  for select using (auth.uid() is not null);
create policy "ships: staff manage" on ships
  for all using (auth_role() = 'staff');

-- ------------------------------------------------------------
-- 3. Screening questionnaire — one set of answers per applicant.
-- ------------------------------------------------------------
create table screening_answers (
  id uuid primary key default gen_random_uuid(),
  applicant_id uuid not null unique references profiles(id) on delete cascade,
  us_c1d_issued_before boolean,
  us_c1d_currently_valid boolean,
  has_onboard_experience boolean,
  can_work_long_hours boolean,
  uncomfortable_clients_answer text,
  drinks_invite_answer text,
  submitted_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table screening_answers enable row level security;

create trigger screening_answers_updated_at before update on screening_answers
  for each row execute procedure set_updated_at();

create policy "screening: applicant manages own" on screening_answers
  for all using (applicant_id = auth.uid()) with check (applicant_id = auth.uid());
create policy "screening: staff read all" on screening_answers
  for select using (auth_role() = 'staff');

-- ------------------------------------------------------------
-- 4. Employee number + ship number verification
-- ------------------------------------------------------------
alter table applications add column if not exists employee_number text;
alter table applications add column if not exists ship_id uuid references ships(id);
alter table applications add column if not exists verified_at timestamptz;

-- The applicant calls this (via lib/actions/applicant.ts -> supabase.rpc)
-- once HR has issued them an employee number and assigned a ship. It
-- only ever touches the caller's own application, and only sets these
-- specific fields — an applicant has no other way to move stage to
-- 'approved' themselves.
create or replace function verify_employment(p_application_id uuid, p_employee_number text, p_ship_id uuid)
returns void as $$
begin
  update applications
  set employee_number = p_employee_number,
      ship_id = p_ship_id,
      verified_at = now(),
      stage = 'approved'
  where id = p_application_id and applicant_id = auth.uid();

  if not found then
    raise exception 'Application not found, or not owned by the current user';
  end if;
end;
$$ language plpgsql security definer;

grant execute on function verify_employment(uuid, text, uuid) to authenticated;
