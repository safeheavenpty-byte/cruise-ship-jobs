// Hand-written starter types matching supabase/migrations/0001_init.sql.
// Once your project is live, replace this with generated types:
//   npx supabase gen types typescript --project-id <your-project-id> > types/database.ts

export type UserRole = "applicant" | "staff" | "partner";
export type JobCategory = "cruise" | "hospitality" | "healthcare";
export type ApplicationStage =
  | "submitted"
  | "exam_pending"
  | "documents_pending"
  | "under_review"
  | "approved"
  | "rejected";
export type DocumentType = "cv" | "police_clearance" | "medical_exam" | "certificate" | "language_accreditation";
export type LanguageTestType = "TOEFL" | "IELTS" | "TOEIC" | "Cambridge" | "JLPT";
export type DocumentStatus = "submitted" | "under_review" | "approved" | "rejected";
export type TravelType = "visa" | "accommodation" | "flight";
export type TravelProvider = "manual" | "api";
export type TravelStatus = "requested" | "in_progress" | "confirmed" | "declined" | "pending";

export interface Profile {
  id: string;
  role: UserRole;
  email: string | null;
  full_name: string | null;
  first_name: string | null;
  last_name: string | null;
  phone: string | null;
  partner_company: string | null;
  country_of_residence: string | null;
  nationality: string | null;
  phone_country_code: string | null;
  phone_number: string | null;
  date_of_birth: string | null;
  gender: string | null;
  referral_source: string | null;
  created_at: string;
}

export interface Job {
  id: string;
  partner_id: string | null;
  category: JobCategory;
  title: string;
  line: string | null;
  contract_length: string | null;
  requirements: string[];
  is_open: boolean;
  created_at: string;
}

export interface Application {
  id: string;
  applicant_id: string;
  job_id: string;
  stage: ApplicationStage;
  reviewed_by: string | null;
  employee_number: string | null;
  ship_id: string | null;
  verified_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface Ship {
  id: string;
  name: string;
  cruise_line: string | null;
  notes: string | null;
  is_active: boolean;
  created_by: string | null;
  created_at: string;
}

export interface ScreeningAnswers {
  id: string;
  applicant_id: string;
  us_c1d_issued_before: boolean | null;
  us_c1d_currently_valid: boolean | null;
  has_onboard_experience: boolean | null;
  can_work_long_hours: boolean | null;
  uncomfortable_clients_answer: string | null;
  drinks_invite_answer: string | null;
  submitted_at: string;
  updated_at: string;
}

export interface ExamResult {
  id: string;
  applicant_id: string;
  category: JobCategory;
  score: number;
  passed: boolean;
  taken_at: string;
}

export interface DocumentRow {
  id: string;
  applicant_id: string;
  type: DocumentType;
  file_path: string;
  test_type: LanguageTestType | null;
  status: DocumentStatus;
  reviewed_by: string | null;
  review_notes: string | null;
  submitted_at: string;
  reviewed_at: string | null;
}

export interface TravelRequest {
  id: string;
  applicant_id: string;
  application_id: string | null;
  type: TravelType;
  provider: TravelProvider;
  provider_ref: string | null;
  status: TravelStatus;
  details: Record<string, unknown>;
  handled_by: string | null;
  accommodation_id: string | null;
  created_at: string;
  updated_at: string;
}

export interface Accommodation {
  id: string;
  title: string;
  location: string | null;
  description: string | null;
  price_info: string | null;
  photo_paths: string[];
  is_available: boolean;
  posted_by: string | null;
  created_at: string;
}

export interface ExamDocument {
  id: string;
  category: JobCategory;
  file_path: string;
  title: string | null;
  uploaded_by: string | null;
  created_at: string;
}

export type InquiryStatus = "new" | "in_progress" | "resolved";

export interface Inquiry {
  id: string;
  sender_id: string | null;
  name: string;
  email: string;
  phone: string | null;
  message: string;
  staff_reply: string | null;
  status: InquiryStatus;
  handled_by: string | null;
  created_at: string;
  updated_at: string;
}

// Minimal Database type so `createClient<Database>()` type-checks.
// Expand with generated types when ready for full query inference.
export interface Database {
  public: {
    Tables: {
      profiles: { Row: Profile; Insert: Partial<Profile>; Update: Partial<Profile> };
      jobs: { Row: Job; Insert: Partial<Job>; Update: Partial<Job> };
      applications: { Row: Application; Insert: Partial<Application>; Update: Partial<Application> };
      exam_results: { Row: ExamResult; Insert: Partial<ExamResult>; Update: Partial<ExamResult> };
      documents: { Row: DocumentRow; Insert: Partial<DocumentRow>; Update: Partial<DocumentRow> };
      travel_requests: { Row: TravelRequest; Insert: Partial<TravelRequest>; Update: Partial<TravelRequest> };
      accommodations: { Row: Accommodation; Insert: Partial<Accommodation>; Update: Partial<Accommodation> };
      exam_documents: { Row: ExamDocument; Insert: Partial<ExamDocument>; Update: Partial<ExamDocument> };
      inquiries: { Row: Inquiry; Insert: Partial<Inquiry>; Update: Partial<Inquiry> };
      ships: { Row: Ship; Insert: Partial<Ship>; Update: Partial<Ship> };
      screening_answers: { Row: ScreeningAnswers; Insert: Partial<ScreeningAnswers>; Update: Partial<ScreeningAnswers> };
    };
  };
}
