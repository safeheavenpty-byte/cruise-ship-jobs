const C = { navy: "#0B2942", warn: "#B5651D", warnBg: "#FBEADD", warnBorder: "#E3B98A" };

// Shown wherever someone might be contacted by a scammer impersonating
// Maritime Cruise Agency — the login page, the public contact page, and inside
// the applicant/partner portals. Keep this short and impossible to miss.
export default function ScamNotice({ compact = false }: { compact?: boolean }) {
  return (
    <div
      className="rounded-xl px-4 py-3 flex gap-3 items-start"
      style={{ background: C.warnBg, border: `1px solid ${C.warnBorder}` }}
    >
      <span style={{ color: C.warn }} className="text-base leading-none mt-0.5">⚠</span>
      <p className="text-xs leading-relaxed" style={{ color: C.navy }}>
        <strong style={{ color: C.warn }}>Maritime Cruise Agency never communicates over WhatsApp.</strong>{" "}
        We don't conduct interviews, request documents, or ask for payment there. Any WhatsApp
        message claiming to represent Maritime Cruise Agency is a scam — do not send money or documents.
        {!compact && " Only trust messages sent through this platform or replies to your submissions below."}
      </p>
    </div>
  );
}
