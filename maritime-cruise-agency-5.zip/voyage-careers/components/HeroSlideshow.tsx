"use client";

import { useEffect, useState } from "react";

const IMAGES = [
  "/hero/hero-1.jpeg",
  "/hero/hero-2.jpeg",
  "/hero/hero-3.jpeg",
  "/hero/hero-4.jpeg",
  "/hero/hero-5.jpeg",
  "/hero/hero-6.jpg",
  "/hero/hero-7.webp",
];

export default function HeroSlideshow() {
  const [index, setIndex] = useState(0);

  useEffect(() => {
    const id = setInterval(() => setIndex((i) => (i + 1) % IMAGES.length), 5000);
    return () => clearInterval(id);
  }, []);

  return (
    <div className="absolute inset-0 overflow-hidden">
      {IMAGES.map((src, i) => (
        // eslint-disable-next-line @next/next/no-img-element
        <img
          key={src}
          src={src}
          alt=""
          className="absolute inset-0 w-full h-full object-cover transition-opacity duration-[1500ms]"
          style={{ opacity: i === index ? 1 : 0 }}
        />
      ))}
      <div
        className="absolute inset-0"
        style={{ background: "linear-gradient(180deg, rgba(11,41,66,0.55) 0%, rgba(11,41,66,0.35) 40%, rgba(11,41,66,0.85) 100%)" }}
      />
      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex gap-2">
        {IMAGES.map((_, i) => (
          <button
            key={i}
            onClick={() => setIndex(i)}
            aria-label={`Slide ${i + 1}`}
            className="w-1.5 h-1.5 rounded-full transition-all"
            style={{ background: i === index ? "#A97C50" : "rgba(255,255,255,0.5)", width: i === index ? 18 : 6 }}
          />
        ))}
      </div>
    </div>
  );
}
