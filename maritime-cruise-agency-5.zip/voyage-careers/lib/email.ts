// Thin wrapper around Resend's REST API — no SDK dependency needed.
// If RESEND_API_KEY isn't set (e.g. local dev without email configured),
// this logs and no-ops instead of throwing, so nothing else breaks.

const FROM = process.env.RESEND_FROM_EMAIL || "Maritime Cruise Agency <notifications@maritimecruiseagency.com>";

export async function sendEmail({ to, subject, html }: { to: string; subject: string; html: string }) {
  const apiKey = process.env.RESEND_API_KEY;

  if (!apiKey) {
    console.warn(`[email] RESEND_API_KEY not set — skipping "${subject}" to ${to}`);
    return;
  }
  if (!to) {
    console.warn(`[email] No recipient address — skipping "${subject}"`);
    return;
  }

  try {
    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ from: FROM, to, subject, html }),
    });
    if (!res.ok) {
      console.error(`[email] Resend API error (${res.status}):`, await res.text());
    }
  } catch (err) {
    // Notification failures should never break the action that triggered
    // them (e.g. a document approval should still succeed even if the
    // email fails to send) — log and move on.
    console.error("[email] Failed to send:", err);
  }
}
