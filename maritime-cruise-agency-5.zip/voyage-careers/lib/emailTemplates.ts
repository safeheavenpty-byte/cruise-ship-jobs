// Simple branded wrapper so every notification email looks consistent
// without pulling in a templating library. Keep this table-based and
// inline-styled — that's still the most reliable approach across email
// clients.

export function emailTemplate(opts: { heading: string; bodyHtml: string; ctaLabel?: string; ctaUrl?: string }) {
  const { heading, bodyHtml, ctaLabel, ctaUrl } = opts;
  return `
  <div style="background:#F7F4EC;padding:32px 16px;font-family:Georgia,serif;">
    <table role="presentation" width="100%" style="max-width:480px;margin:0 auto;background:#FFFFFF;border-radius:12px;overflow:hidden;border:1px solid #E3DCC9;">
      <tr>
        <td style="background:#0B2942;padding:24px 28px;">
          <span style="color:#A97C50;font-size:18px;">Maritime Cruise Agency</span>
        </td>
      </tr>
      <tr>
        <td style="padding:28px;font-family:Arial,sans-serif;">
          <h1 style="color:#0B2942;font-size:20px;margin:0 0 16px 0;font-family:Georgia,serif;">${heading}</h1>
          <div style="color:#3E4C57;font-size:14px;line-height:1.6;">${bodyHtml}</div>
          ${
            ctaLabel && ctaUrl
              ? `<a href="${ctaUrl}" style="display:inline-block;margin-top:20px;background:#A97C50;color:#FFFFFF;text-decoration:none;font-size:13px;font-weight:bold;padding:10px 20px;border-radius:999px;">${ctaLabel}</a>`
              : ""
          }
        </td>
      </tr>
      <tr>
        <td style="padding:16px 28px;border-top:1px solid #E3DCC9;font-family:Arial,sans-serif;">
          <p style="color:#8A9BAA;font-size:11px;margin:0;">
            Maritime Cruise Agency never communicates over WhatsApp. This email, and messages inside
            your account dashboard, are the only official channels we use.
          </p>
        </td>
      </tr>
    </table>
  </div>`;
}
