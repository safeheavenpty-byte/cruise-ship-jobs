"use server";

import { createClient } from "@/lib/supabase/server";
import { revalidatePath } from "next/cache";
import { sendEmail } from "@/lib/email";
import { emailTemplate } from "@/lib/emailTemplates";
import type { DocumentStatus, ApplicationStage, TravelStatus, JobCategory } from "@/types/database";

const APP_URL = process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000";

const DOC_LABELS: Record<string, string> = {
  cv: "CV / Résumé",
  police_clearance: "Police Clearance",
  medical_exam: "Medical Exam Records",
  certificate: "Qualification Certificate",
  language_accreditation: "Language Accreditation",
};

// All three actions rely on RLS policies ("staff: read/update all") to
// enforce that only staff-role users can actually perform the update —
// this is a server-side convenience wrapper, not the security boundary.

export async function updateDocumentStatus(
  documentId: string,
  status: DocumentStatus,
  reviewNotes?: string
) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  const { data: doc } = await supabase
    .from("documents")
    .select("type, applicant_id, profiles:applicant_id (email, full_name)")
    .eq("id", documentId)
    .single();

  const { error } = await supabase
    .from("documents")
    .update({
      status,
      review_notes: reviewNotes ?? null,
      reviewed_by: user?.id,
      reviewed_at: new Date().toISOString(),
    })
    .eq("id", documentId);

  if (error) throw new Error(error.message);

  if (doc && (status === "approved" || status === "rejected")) {
    const profile = (doc as any).profiles;
    const label = DOC_LABELS[doc.type] ?? doc.type;
    await sendEmail({
      to: profile?.email,
      subject: `Your ${label} was ${status}`,
      html: emailTemplate({
        heading: status === "approved" ? "Document approved" : "Document needs attention",
        bodyHtml:
          status === "approved"
            ? `<p>Hi ${profile?.full_name ?? "there"},</p><p>Your <strong>${label}</strong> has been reviewed and approved. Check your document wallet to see your overall progress.</p>${reviewNotes ? `<p><em>Note from our team: ${reviewNotes}</em></p>` : ""}`
            : `<p>Hi ${profile?.full_name ?? "there"},</p><p>Your <strong>${label}</strong> submission needs another look. Please re-upload it in your document wallet.</p>${reviewNotes ? `<p><em>Note from our team: ${reviewNotes}</em></p>` : ""}`,
        ctaLabel: "View my documents",
        ctaUrl: `${APP_URL}/app/documents`,
      }),
    });
  }

  revalidatePath("/staff/documents");
  revalidatePath("/staff");
}

export async function updateApplicationStage(applicationId: string, stage: ApplicationStage) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  const { data: application } = await supabase
    .from("applications")
    .select("applicant_id, profiles:applicant_id (email, full_name), jobs:job_id (title)")
    .eq("id", applicationId)
    .single();

  const { error } = await supabase
    .from("applications")
    .update({ stage, reviewed_by: user?.id })
    .eq("id", applicationId);

  if (error) throw new Error(error.message);

  if (application) {
    const profile = (application as any).profiles;
    const job = (application as any).jobs;
    await sendEmail({
      to: profile?.email,
      subject: `Update on your application: ${job?.title ?? "your role"}`,
      html: emailTemplate({
        heading: "Your application status changed",
        bodyHtml: `<p>Hi ${profile?.full_name ?? "there"},</p><p>Your application for <strong>${job?.title ?? "your role"}</strong> is now: <strong>${stage.replace("_", " ")}</strong>.</p>`,
        ctaLabel: "View my applications",
        ctaUrl: `${APP_URL}/app/applications`,
      }),
    });
  }

  revalidatePath("/staff/applications");
  revalidatePath("/staff");
}

export async function updateTravelStatus(travelRequestId: string, status: TravelStatus) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  const { data: request } = await supabase
    .from("travel_requests")
    .select("type, applicant_id, profiles:applicant_id (email, full_name)")
    .eq("id", travelRequestId)
    .single();

  const { error } = await supabase
    .from("travel_requests")
    .update({ status, handled_by: user?.id })
    .eq("id", travelRequestId);

  if (error) throw new Error(error.message);

  if (request) {
    const profile = (request as any).profiles;
    await sendEmail({
      to: profile?.email,
      subject: `Update on your ${request.type} request`,
      html: emailTemplate({
        heading: "Your travel request status changed",
        bodyHtml: `<p>Hi ${profile?.full_name ?? "there"},</p><p>Your <strong>${request.type}</strong> request is now: <strong>${status.replace("_", " ")}</strong>.</p>`,
        ctaLabel: "View my travel",
        ctaUrl: `${APP_URL}/app/travel`,
      }),
    });
  }

  revalidatePath("/staff/travel");
  revalidatePath("/staff");
}

// ------------------------------------------------------------
// Exam PDFs
// ------------------------------------------------------------

export async function createExamDocument(category: JobCategory, filePath: string, title: string) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) throw new Error("Not signed in");

  const { error } = await supabase
    .from("exam_documents")
    .insert({ category, file_path: filePath, title, uploaded_by: user.id });

  if (error) throw new Error(error.message);
  revalidatePath("/staff/exams");
  revalidatePath("/app/exams");
}

// ------------------------------------------------------------
// Accommodation listings
// ------------------------------------------------------------

export async function createAccommodation(input: {
  title: string;
  location: string;
  description: string;
  price_info: string;
  photo_paths: string[];
}) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) throw new Error("Not signed in");

  const { error } = await supabase.from("accommodations").insert({ ...input, posted_by: user.id, is_available: true });
  if (error) throw new Error(error.message);
  revalidatePath("/staff/accommodations");
  revalidatePath("/app/travel");
}

export async function toggleAccommodationAvailable(id: string, isAvailable: boolean) {
  const supabase = await createClient();
  const { error } = await supabase.from("accommodations").update({ is_available: isAvailable }).eq("id", id);
  if (error) throw new Error(error.message);
  revalidatePath("/staff/accommodations");
  revalidatePath("/app/travel");
}

// Staff assigns a specific accommodation listing to an applicant's
// request. If the applicant's documents aren't all approved yet, the
// request is forced to stay 'pending' rather than 'confirmed' — this
// is the enforcement point for "pending while documents are under review".
export async function assignAccommodation(travelRequestId: string, accommodationId: string | null) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) throw new Error("Not signed in");

  const { data: request } = await supabase
    .from("travel_requests")
    .select("applicant_id, profiles:applicant_id (email, full_name)")
    .eq("id", travelRequestId)
    .single();
  if (!request) throw new Error("Travel request not found");

  const { count: unapprovedDocs } = await supabase
    .from("documents")
    .select("*", { count: "exact", head: true })
    .eq("applicant_id", request.applicant_id)
    .neq("status", "approved");

  const documentsCleared = (unapprovedDocs ?? 0) === 0;
  const status: TravelStatus = accommodationId && documentsCleared ? "confirmed" : "pending";

  const { error } = await supabase
    .from("travel_requests")
    .update({ accommodation_id: accommodationId, status, handled_by: user.id })
    .eq("id", travelRequestId);

  if (error) throw new Error(error.message);

  if (status === "confirmed") {
    const profile = (request as any).profiles;
    const { data: listing } = await supabase.from("accommodations").select("title, location").eq("id", accommodationId).single();
    await sendEmail({
      to: profile?.email,
      subject: "Your accommodation is confirmed",
      html: emailTemplate({
        heading: "Accommodation confirmed",
        bodyHtml: `<p>Hi ${profile?.full_name ?? "there"},</p><p>You're confirmed at <strong>${listing?.title ?? "your accommodation"}</strong>${listing?.location ? ` in ${listing.location}` : ""}.</p>`,
        ctaLabel: "View details",
        ctaUrl: `${APP_URL}/app/travel`,
      }),
    });
  }

  revalidatePath("/staff/travel");
  revalidatePath("/app/travel");
}

// ------------------------------------------------------------
// Ships under management
// ------------------------------------------------------------

export async function createShip(input: { name: string; cruise_line: string; notes: string }) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) throw new Error("Not signed in");

  const { error } = await supabase.from("ships").insert({ ...input, created_by: user.id, is_active: true });
  if (error) throw new Error(error.message);
  revalidatePath("/staff/ships");
  revalidatePath("/app/applications");
}

export async function toggleShipActive(id: string, isActive: boolean) {
  const supabase = await createClient();
  const { error } = await supabase.from("ships").update({ is_active: isActive }).eq("id", id);
  if (error) throw new Error(error.message);
  revalidatePath("/staff/ships");
  revalidatePath("/app/applications");
}

export async function updateShip(id: string, input: { name: string; cruise_line: string; notes: string }) {
  const supabase = await createClient();
  const { error } = await supabase.from("ships").update(input).eq("id", id);
  if (error) throw new Error(error.message);
  revalidatePath("/staff/ships");
  revalidatePath("/app/applications");
}
