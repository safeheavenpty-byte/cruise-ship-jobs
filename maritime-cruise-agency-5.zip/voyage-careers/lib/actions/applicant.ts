"use server";

import { createClient } from "@/lib/supabase/server";
import { revalidatePath } from "next/cache";
import { sendEmail } from "@/lib/email";
import { emailTemplate } from "@/lib/emailTemplates";
import type { JobCategory, TravelType } from "@/types/database";

const APP_URL = process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000";

// Called from the login page right after a successful sign-up. Kept as
// its own small action (rather than bundled into the trigger) since
// sending email from inside a Postgres trigger isn't practical here.
export async function sendWelcomeEmail(name: string, email: string) {
  await sendEmail({
    to: email,
    subject: "Welcome to Maritime Cruise Agency",
    html: emailTemplate({
      heading: "Thank you for registering!",
      bodyHtml: `<p>Hi ${name || "there"},</p><p>Please proceed to submitting your documents to finish your application: CV, language accreditation, qualification certificates, medical exam results, and police clearance certificate.</p>`,
      ctaLabel: "Submit my documents",
      ctaUrl: `${APP_URL}/app/documents`,
    }),
  });
}

// RLS ("applicant inserts own") is the real security boundary here —
// these actions just make the calls ergonomic from Client Components.

export async function applyToJob(jobId: string) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) throw new Error("Not signed in");

  const { error } = await supabase
    .from("applications")
    .insert({ applicant_id: user.id, job_id: jobId, stage: "submitted" });

  if (error && error.code !== "23505") {
    // 23505 = unique violation (already applied) — treat as a no-op, not an error
    throw new Error(error.message);
  }
  revalidatePath("/app/jobs");
  revalidatePath("/app");
}

export async function submitExamResult(category: JobCategory, score: number, passed: boolean) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) throw new Error("Not signed in");

  const { error } = await supabase
    .from("exam_results")
    .insert({ applicant_id: user.id, category, score, passed });

  if (error) throw new Error(error.message);
  revalidatePath("/app/exams");
  revalidatePath("/app");
}

export async function requestTravel(
  type: TravelType,
  details: Record<string, unknown> = {},
  accommodationId?: string | null
) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) throw new Error("Not signed in");

  // Accommodation requests always start 'pending' — staff still need to
  // confirm the specific listing and check the applicant's documents are
  // cleared before it can move to 'confirmed'.
  const status = type === "accommodation" ? "pending" : "requested";

  const { error } = await supabase.from("travel_requests").insert({
    applicant_id: user.id,
    type,
    details,
    status,
    provider: "manual",
    accommodation_id: type === "accommodation" ? accommodationId ?? null : null,
  });

  if (error) throw new Error(error.message);
  revalidatePath("/app/travel");
  revalidatePath("/app");
}

// ------------------------------------------------------------
// Screening questionnaire — one row per applicant, upserted so they
// can revisit and update their answers before final review.
// ------------------------------------------------------------

export async function saveScreeningAnswers(answers: {
  us_c1d_issued_before: boolean;
  us_c1d_currently_valid: boolean;
  has_onboard_experience: boolean;
  can_work_long_hours: boolean;
  uncomfortable_clients_answer: string;
  drinks_invite_answer: string;
}) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) throw new Error("Not signed in");

  const { error } = await supabase
    .from("screening_answers")
    .upsert({ applicant_id: user.id, ...answers }, { onConflict: "applicant_id" });

  if (error) throw new Error(error.message);
  revalidatePath("/app/screening");
  revalidatePath("/staff/screening");
}

// ------------------------------------------------------------
// Employee number + ship number verification. Routed through a
// SECURITY DEFINER Postgres function (see migration 5) rather than a
// direct table update, so this is the only way an applicant can move
// their own application to 'approved'.
// ------------------------------------------------------------

export async function verifyEmployment(applicationId: string, employeeNumber: string, shipId: string) {
  const supabase = await createClient();
  const { error } = await supabase.rpc("verify_employment", {
    p_application_id: applicationId,
    p_employee_number: employeeNumber,
    p_ship_id: shipId,
  });

  if (error) throw new Error(error.message);

  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (user) {
    const [{ data: profile }, { data: ship }] = await Promise.all([
      supabase.from("profiles").select("email, full_name").eq("id", user.id).single(),
      supabase.from("ships").select("name").eq("id", shipId).single(),
    ]);
    await sendEmail({
      to: profile?.email ?? "",
      subject: "You're verified & approved",
      html: emailTemplate({
        heading: "Verified & approved — awaiting visa submission",
        bodyHtml: `<p>Hi ${profile?.full_name ?? "there"},</p><p>Your employee number and ship assignment (<strong>${ship?.name ?? "your ship"}</strong>) have been confirmed. Your application is now approved and awaiting visa submission.</p>`,
        ctaLabel: "View my applications",
        ctaUrl: `${APP_URL}/app/applications`,
      }),
    });
  }

  revalidatePath("/app/applications");
  revalidatePath("/app");
}
