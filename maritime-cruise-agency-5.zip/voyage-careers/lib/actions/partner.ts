"use server";

import { createClient } from "@/lib/supabase/server";
import { revalidatePath } from "next/cache";
import type { JobCategory } from "@/types/database";

// RLS ("jobs: partner manages own" / "partner updates own") is the real
// security boundary — a partner cannot create or edit a job that isn't
// theirs, and cannot see applications to jobs they don't own.

export async function createJob(input: {
  category: JobCategory;
  title: string;
  line: string;
  contract_length: string;
  requirements: string[];
}) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) throw new Error("Not signed in");

  const { error } = await supabase.from("jobs").insert({ ...input, partner_id: user.id, is_open: true });
  if (error) throw new Error(error.message);
  revalidatePath("/partner/jobs");
  revalidatePath("/partner");
}

export async function toggleJobOpen(jobId: string, isOpen: boolean) {
  const supabase = await createClient();
  const { error } = await supabase.from("jobs").update({ is_open: isOpen }).eq("id", jobId);
  if (error) throw new Error(error.message);
  revalidatePath("/partner/jobs");
  revalidatePath("/partner");
}
