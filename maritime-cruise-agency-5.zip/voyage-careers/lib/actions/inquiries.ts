"use server";

import { createClient } from "@/lib/supabase/server";
import { revalidatePath } from "next/cache";
import { sendEmail } from "@/lib/email";
import { emailTemplate } from "@/lib/emailTemplates";
import type { InquiryStatus } from "@/types/database";

const APP_URL = process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000";

// Anyone can call this — signed in or not (the public /contact page has
// no auth requirement). RLS enforces that an anonymous submitter can
// only leave sender_id null, and a signed-in user can only attach
// themselves, never impersonate someone else.
export async function submitInquiry(input: { name: string; email: string; phone?: string; message: string }) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  const { error } = await supabase.from("inquiries").insert({
    sender_id: user?.id ?? null,
    name: input.name,
    email: input.email,
    phone: input.phone ?? null,
    message: input.message,
    status: "new",
  });

  if (error) throw new Error(error.message);
  revalidatePath("/staff/inquiries");
  revalidatePath("/app/messages");
  revalidatePath("/partner/messages");
}

export async function replyToInquiry(id: string, reply: string, status: InquiryStatus) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) throw new Error("Not signed in");

  const { data: inquiry } = await supabase.from("inquiries").select("name, email, message").eq("id", id).single();

  const { error } = await supabase
    .from("inquiries")
    .update({ staff_reply: reply, status, handled_by: user.id })
    .eq("id", id);

  if (error) throw new Error(error.message);

  if (inquiry?.email && reply) {
    await sendEmail({
      to: inquiry.email,
      subject: "Reply to your message",
      html: emailTemplate({
        heading: "We replied to your message",
        bodyHtml: `<p>Hi ${inquiry.name},</p><p>You wrote: <em>"${inquiry.message.slice(0, 200)}${inquiry.message.length > 200 ? "…" : ""}"</em></p><p><strong>Our reply:</strong></p><p>${reply}</p><p style="margin-top:16px;">Remember — this is the only place and email address we'll ever contact you from. We never use WhatsApp.</p>`,
        ctaLabel: "View this conversation",
        ctaUrl: `${APP_URL}/contact`,
      }),
    });
  }

  revalidatePath("/staff/inquiries");
  revalidatePath("/app/messages");
  revalidatePath("/partner/messages");
}
