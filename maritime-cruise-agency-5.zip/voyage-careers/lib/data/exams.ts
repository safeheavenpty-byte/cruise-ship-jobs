// Exam content lives in code for now rather than the database — there's
// no admin UI yet to author questions. Results are still persisted to
// `exam_results` per applicant. If you later want staff to edit exam
// content without a deploy, this is the natural next table to add
// (e.g. `exam_questions` keyed by category).

import type { JobCategory } from "@/types/database";

export const EXAMS: Record<JobCategory, { title: string; questions: { q: string; options: string[]; answer: number }[] }> = {
  cruise: {
    title: "Cruise Operations & Safety",
    questions: [
      { q: "What does STCW stand for?", options: ["Standard Training, Certification and Watchkeeping", "Ship Transport Cargo Weighing", "Safe Travel Cruise Worker", "Sea Trade Crew Wages"], answer: 0 },
      { q: "In a muster drill, your first responsibility is to:", options: ["Continue serving guests", "Report to your assigned station", "Wait for further notice in your cabin", "Contact your agency"], answer: 1 },
      { q: "An ENG-1 (or equivalent) certifies:", options: ["Language proficiency", "Medical fitness for sea duty", "Culinary qualification", "Visa eligibility"], answer: 1 },
    ],
  },
  hospitality: {
    title: "Guest Service Standards",
    questions: [
      { q: "A guest complains about a late check-in. Best first step?", options: ["Apologize and offer a solution", "Explain hotel policy at length", "Refer them to another department", "Ignore until shift change"], answer: 0 },
      { q: "HACCP primarily relates to:", options: ["Housekeeping schedules", "Food safety management", "Front desk billing", "Staff rostering"], answer: 1 },
      { q: "Which best describes 'upselling'?", options: ["Overcharging a guest", "Offering a relevant upgrade or add-on", "Discounting a room rate", "Cancelling a reservation"], answer: 1 },
    ],
  },
  healthcare: {
    title: "Clinical & Patient Care Basics",
    questions: [
      { q: "BLS certification primarily covers:", options: ["Billing procedures", "Basic life support / CPR", "Medication inventory", "Shift scheduling"], answer: 1 },
      { q: "Before administering care, you should always:", options: ["Confirm patient identity and consent", "Start immediately", "Ask a colleague to do it", "Skip documentation"], answer: 0 },
      { q: "A police clearance certificate is typically required to:", options: ["Verify driving ability", "Confirm no disqualifying criminal history", "Prove language skill", "Waive medical exams"], answer: 1 },
    ],
  },
};
