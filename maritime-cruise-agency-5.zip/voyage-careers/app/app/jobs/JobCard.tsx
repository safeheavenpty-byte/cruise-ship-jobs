"use client";

import { useState, useTransition } from "react";
import { applyToJob } from "@/lib/actions/applicant";

const C = { surface: "#FFFFFF", gold: "#A97C50", paper: "#0B2942", paperDim: "#5B7286", hairline: "#E3DCC9" };

export default function JobCard({
  job,
  alreadyApplied,
}: {
  job: { id: string; title: string; line: string | null; contract_length: string | null; requirements: string[] };
  alreadyApplied: boolean;
}) {
  const [open, setOpen] = useState(false);
  const [applied, setApplied] = useState(alreadyApplied);
  const [isPending, startTransition] = useTransition();

  function apply() {
    startTransition(async () => {
      await applyToJob(job.id);
      setApplied(true);
      setOpen(false);
    });
  }

  return (
    <div className="rounded-xl p-5" style={{ background: C.surface, border: `1px solid ${C.hairline}` }}>
      <div className="flex justify-between items-start">
        <div>
          <h3 className="text-lg" style={{ color: C.paper, fontFamily: "serif" }}>{job.title}</h3>
          <p className="text-xs mt-0.5" style={{ color: C.gold }}>{job.line}</p>
        </div>
        <span className="text-[11px]" style={{ color: C.paperDim, fontFamily: "monospace" }}>{job.contract_length}</span>
      </div>

      {open && (
        <ul className="mt-4 space-y-1.5">
          {job.requirements.map((r) => (
            <li key={r} className="text-sm flex gap-2" style={{ color: C.paper }}>
              <span style={{ color: C.gold }}>—</span> {r}
            </li>
          ))}
        </ul>
      )}

      <div className="flex justify-between items-center mt-4">
        <button onClick={() => setOpen(!open)} className="text-sm" style={{ color: C.paper }}>
          {open ? "Hide requirements" : "View requirements"}
        </button>
        {applied ? (
          <span className="text-xs" style={{ color: C.gold }}>Applied</span>
        ) : (
          <button
            disabled={isPending}
            onClick={apply}
            className="text-xs font-semibold px-3 py-1.5 rounded-full disabled:opacity-50"
            style={{ background: C.gold, color: "#0B2942" }}
          >
            Apply
          </button>
        )}
      </div>
    </div>
  );
}
