import { createClient } from "@/lib/supabase/server";
import JobCard from "./JobCard";
import type { JobCategory } from "@/types/database";

const C = { gold: "#A97C50", paper: "#0B2942", paperDim: "#5B7286" };
const CATEGORY_LABELS: Record<JobCategory, string> = { cruise: "Cruise Ship", hospitality: "Hospitality", healthcare: "Healthcare" };

export default async function JobsPage() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  const [{ data: jobs }, { data: myApplications }] = await Promise.all([
    supabase.from("jobs").select("*").eq("is_open", true).order("created_at", { ascending: false }),
    supabase.from("applications").select("job_id").eq("applicant_id", user!.id),
  ]);

  const appliedIds = new Set((myApplications ?? []).map((a) => a.job_id));
  const categories: JobCategory[] = ["cruise", "hospitality", "healthcare"];

  return (
    <div>
      <p className="text-xs mb-1" style={{ color: C.gold, fontFamily: "monospace" }}>OPEN POSITIONS</p>
      <h1 className="text-3xl mb-8" style={{ color: C.paper, fontFamily: "serif" }}>Find your next contract</h1>

      {categories.map((cat) => {
        const catJobs = (jobs ?? []).filter((j) => j.category === cat);
        if (catJobs.length === 0) return null;
        return (
          <div key={cat} className="mb-8">
            <h2 className="text-sm mb-3" style={{ color: C.paperDim }}>{CATEGORY_LABELS[cat]}</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {catJobs.map((job) => (
                <JobCard key={job.id} job={job} alreadyApplied={appliedIds.has(job.id)} />
              ))}
            </div>
          </div>
        );
      })}

      {(!jobs || jobs.length === 0) && (
        <p className="text-sm" style={{ color: C.paperDim }}>No open positions right now — check back soon.</p>
      )}
    </div>
  );
}
