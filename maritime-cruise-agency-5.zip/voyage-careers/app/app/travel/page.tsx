"use client";

import { useEffect, useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { requestTravel } from "@/lib/actions/applicant";
import type { TravelType, TravelStatus, Accommodation } from "@/types/database";

const C = {
  surface: "#FFFFFF",
  gold: "#A97C50",
  paper: "#0B2942",
  paperDim: "#5B7286",
  hairline: "#E3DCC9",
  ok: "#4F8B6E",
  warn: "#B5651D",
};

const NON_ACCOMMODATION: { id: TravelType; label: string; desc: string }[] = [
  { id: "visa", label: "Work Visa", desc: "Apply for the work visa attached to your accepted contract." },
  { id: "flight", label: "Flights", desc: "Request travel booking to your point of embarkation or duty station." },
];

type AccommodationRequest = {
  id: string;
  status: TravelStatus;
  accommodation_id: string | null;
};

export default function TravelPage() {
  const supabase = createClient();
  const [simpleStatus, setSimpleStatus] = useState<Record<string, TravelStatus>>({});
  const [pending, setPending] = useState<string | null>(null);

  const [accommodationRequest, setAccommodationRequest] = useState<AccommodationRequest | null>(null);
  const [listings, setListings] = useState<Accommodation[]>([]);
  const [documentsCleared, setDocumentsCleared] = useState(false);
  const [loading, setLoading] = useState(true);

  function photoUrl(path: string) {
    return supabase.storage.from("accommodation-photos").getPublicUrl(path).data.publicUrl;
  }

  async function load() {
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) return;

    const [{ data: travel }, { data: accs }, { data: docs }] = await Promise.all([
      supabase
        .from("travel_requests")
        .select("id, type, status, accommodation_id")
        .eq("applicant_id", user.id)
        .order("created_at", { ascending: false }),
      supabase.from("accommodations").select("*").eq("is_available", true).order("created_at", { ascending: false }),
      supabase.from("documents").select("status").eq("applicant_id", user.id),
    ]);

    const simple: Record<string, TravelStatus> = {};
    let accReq: AccommodationRequest | null = null;
    (travel ?? []).forEach((r: any) => {
      if (r.type === "accommodation") {
        if (!accReq) accReq = { id: r.id, status: r.status, accommodation_id: r.accommodation_id };
      } else if (!simple[r.type]) {
        simple[r.type] = r.status;
      }
    });

    setSimpleStatus(simple);
    setAccommodationRequest(accReq);
    setListings((accs ?? []) as Accommodation[]);
    setDocumentsCleared((docs ?? []).length > 0 && (docs ?? []).every((d) => d.status === "approved"));
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  async function submitSimple(type: TravelType) {
    setPending(type);
    await requestTravel(type);
    await load();
    setPending(null);
  }

  async function submitAccommodation(accommodationId: string | null) {
    setPending("accommodation");
    await requestTravel("accommodation", {}, accommodationId);
    await load();
    setPending(null);
  }

  const assignedListing = accommodationRequest?.accommodation_id
    ? listings.find((l) => l.id === accommodationRequest.accommodation_id)
    : null;

  return (
    <div>
      <p className="text-xs mb-1" style={{ color: C.gold, fontFamily: "monospace" }}>TRAVEL & LOGISTICS</p>
      <h1 className="text-3xl mb-8" style={{ color: C.paper, fontFamily: "serif" }}>Arrange your journey</h1>

      {/* Visa + Flights — simple request/status */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-10">
        {NON_ACCOMMODATION.map(({ id, label, desc }) => {
          const status = simpleStatus[id];
          return (
            <div key={id} className="rounded-xl p-5 flex flex-col" style={{ background: C.surface, border: `1px solid ${C.hairline}` }}>
              <h3 className="text-lg" style={{ color: C.paper, fontFamily: "serif" }}>{label}</h3>
              <p className="text-xs mt-1 mb-4 flex-1" style={{ color: C.paperDim }}>{desc}</p>
              {status ? (
                <span className="text-xs" style={{ color: status === "confirmed" ? C.ok : C.gold }}>
                  {status.replace("_", " ")}
                </span>
              ) : (
                <button
                  disabled={pending === id}
                  onClick={() => submitSimple(id)}
                  className="text-xs font-semibold px-3 py-1.5 rounded-full disabled:opacity-50"
                  style={{ background: C.gold, color: "#0B2942" }}
                >
                  {pending === id ? "Requesting…" : "Request"}
                </button>
              )}
            </div>
          );
        })}
      </div>

      {/* Accommodation — browse listings with photos, request, or track pending status */}
      <p className="text-xs mb-1" style={{ color: C.gold, fontFamily: "monospace" }}>ACCOMMODATION</p>
      <h2 className="text-xl mb-4" style={{ color: C.paper, fontFamily: "serif" }}>Places available for booking</h2>

      {loading ? (
        <p className="text-sm" style={{ color: C.paperDim }}>Loading…</p>
      ) : accommodationRequest ? (
        <div className="rounded-xl p-5" style={{ background: C.surface, border: `1px solid ${C.hairline}` }}>
          {accommodationRequest.status === "confirmed" && assignedListing ? (
            <>
              {assignedListing.photo_paths.length > 0 && (
                <div className="grid grid-cols-3 gap-1 mb-4 rounded-lg overflow-hidden">
                  {assignedListing.photo_paths.slice(0, 3).map((p) => (
                    <img key={p} src={photoUrl(p)} alt={assignedListing.title} className="w-full h-28 object-cover" />
                  ))}
                </div>
              )}
              <p className="text-sm" style={{ color: C.paper }}>{assignedListing.title}</p>
              <p className="text-xs mt-0.5" style={{ color: C.paperDim }}>{assignedListing.location}</p>
              {assignedListing.description && (
                <p className="text-xs mt-2" style={{ color: C.paperDim }}>{assignedListing.description}</p>
              )}
              <span className="inline-block mt-3 text-xs font-semibold px-3 py-1 rounded-full" style={{ background: C.ok, color: "#0B2942" }}>
                Confirmed
              </span>
            </>
          ) : (
            <>
              <span className="inline-block text-xs font-semibold px-3 py-1 rounded-full mb-3" style={{ background: "#FFFFFF", color: C.gold, border: `1px solid ${C.hairline}` }}>
                Pending
              </span>
              <p className="text-sm" style={{ color: C.paperDim }}>
                {!documentsCleared
                  ? "Your accommodation can't be confirmed until your submitted documents finish review."
                  : "We're still sourcing a place for you — check back soon."}
              </p>
            </>
          )}
        </div>
      ) : (
        <>
          <p className="text-xs mb-4" style={{ color: C.paperDim }}>
            Pick a place below, or request accommodation without choosing one yet — either way it starts as pending
            until confirmed.
          </p>
          {listings.length === 0 ? (
            <div className="rounded-xl p-5" style={{ background: C.surface, border: `1px solid ${C.hairline}` }}>
              <p className="text-sm mb-3" style={{ color: C.paperDim }}>No listings posted yet.</p>
              <button
                disabled={pending === "accommodation"}
                onClick={() => submitAccommodation(null)}
                className="text-xs font-semibold px-4 py-2 rounded-full disabled:opacity-50"
                style={{ background: C.gold, color: "#0B2942" }}
              >
                {pending === "accommodation" ? "Requesting…" : "Request accommodation"}
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {listings.map((listing) => (
                <div key={listing.id} className="rounded-xl overflow-hidden" style={{ background: C.surface, border: `1px solid ${C.hairline}` }}>
                  {listing.photo_paths.length > 0 && (
                    <div className="grid grid-cols-3 gap-0.5">
                      {listing.photo_paths.slice(0, 3).map((p) => (
                        <img key={p} src={photoUrl(p)} alt={listing.title} className="w-full h-24 object-cover" />
                      ))}
                    </div>
                  )}
                  <div className="p-4">
                    <p className="text-sm" style={{ color: C.paper }}>{listing.title}</p>
                    <p className="text-xs mt-0.5" style={{ color: C.paperDim }}>{listing.location}</p>
                    {listing.price_info && <p className="text-xs mt-1" style={{ color: C.gold }}>{listing.price_info}</p>}
                    <button
                      disabled={pending === "accommodation"}
                      onClick={() => submitAccommodation(listing.id)}
                      className="text-xs font-semibold px-3 py-1.5 rounded-full mt-3 disabled:opacity-50"
                      style={{ background: C.gold, color: "#0B2942" }}
                    >
                      {pending === "accommodation" ? "Requesting…" : "Request this one"}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </>
      )}
    </div>
  );
}
