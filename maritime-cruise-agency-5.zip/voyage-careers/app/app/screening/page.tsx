"use client";

import { useEffect, useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { saveScreeningAnswers } from "@/lib/actions/applicant";

const C = { surface: "#FFFFFF", wood: "#A97C50", navy: "#0B2942", navyDim: "#5B7286", border: "#E3DCC9", ok: "#4F8B6E", warn: "#B5651D" };

const WORD_LIMIT = 300;

function wordCount(text: string) {
  return text.trim().split(/\s+/).filter(Boolean).length;
}

function YesNo({ label, value, onChange }: { label: string; value: boolean | null; onChange: (v: boolean) => void }) {
  return (
    <div className="rounded-xl p-4" style={{ background: C.surface, border: `1px solid ${C.border}` }}>
      <p className="text-sm mb-3" style={{ color: C.navy }}>{label}</p>
      <div className="flex gap-2">
        {[true, false].map((opt) => (
          <button
            key={String(opt)}
            type="button"
            onClick={() => onChange(opt)}
            className="text-xs font-semibold px-4 py-2 rounded-full"
            style={{
              background: value === opt ? C.wood : "#F7F4EC",
              color: value === opt ? "#FFFFFF" : C.navyDim,
              border: `1px solid ${value === opt ? C.wood : C.border}`,
            }}
          >
            {opt ? "Yes" : "No"}
          </button>
        ))}
      </div>
    </div>
  );
}

export default function ScreeningPage() {
  const supabase = createClient();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [c1dIssued, setC1dIssued] = useState<boolean | null>(null);
  const [c1dValid, setC1dValid] = useState<boolean | null>(null);
  const [onboardExp, setOnboardExp] = useState<boolean | null>(null);
  const [longHours, setLongHours] = useState<boolean | null>(null);
  const [uncomfortableAnswer, setUncomfortableAnswer] = useState("");
  const [drinksAnswer, setDrinksAnswer] = useState("");

  useEffect(() => {
    (async () => {
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (!user) return;
      const { data } = await supabase.from("screening_answers").select("*").eq("applicant_id", user.id).maybeSingle();
      if (data) {
        setC1dIssued(data.us_c1d_issued_before);
        setC1dValid(data.us_c1d_currently_valid);
        setOnboardExp(data.has_onboard_experience);
        setLongHours(data.can_work_long_hours);
        setUncomfortableAnswer(data.uncomfortable_clients_answer ?? "");
        setDrinksAnswer(data.drinks_invite_answer ?? "");
      }
      setLoading(false);
    })();
  }, []);

  const uncomfortableWords = wordCount(uncomfortableAnswer);
  const drinksWords = wordCount(drinksAnswer);
  const overLimit = uncomfortableWords > WORD_LIMIT || drinksWords > WORD_LIMIT;
  const allAnswered = c1dIssued !== null && c1dValid !== null && onboardExp !== null && longHours !== null && uncomfortableAnswer.trim() && drinksAnswer.trim();

  async function submit() {
    setError(null);
    if (overLimit) {
      setError(`Please keep each answer to ${WORD_LIMIT} words or fewer.`);
      return;
    }
    setSaving(true);
    try {
      await saveScreeningAnswers({
        us_c1d_issued_before: c1dIssued!,
        us_c1d_currently_valid: c1dValid!,
        has_onboard_experience: onboardExp!,
        can_work_long_hours: longHours!,
        uncomfortable_clients_answer: uncomfortableAnswer.trim(),
        drinks_invite_answer: drinksAnswer.trim(),
      });
      setSaved(true);
      setTimeout(() => setSaved(false), 2000);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setSaving(false);
    }
  }

  if (loading) return <p className="text-sm" style={{ color: C.navyDim }}>Loading…</p>;

  return (
    <div className="max-w-xl">
      <p className="text-xs mb-1" style={{ color: C.wood, fontFamily: "monospace" }}>SCREENING QUESTIONNAIRE</p>
      <h1 className="text-3xl mb-2" style={{ color: C.navy, fontFamily: "serif" }}>A few questions before we proceed</h1>
      <p className="text-xs mb-8" style={{ color: C.navyDim }}>
        Answer honestly — this helps us match you to the right roles and prepare your visa paperwork correctly.
      </p>

      <div className="space-y-3 mb-6">
        <YesNo label="Have you been issued a US C1/D visa in the past?" value={c1dIssued} onChange={setC1dIssued} />
        <YesNo label="Do you currently have a valid US C1/D visa?" value={c1dValid} onChange={setC1dValid} />
        <YesNo label="Do you have any experience working on board?" value={onboardExp} onChange={setOnboardExp} />
        <YesNo label="Can you work under pressure for long hours?" value={longHours} onChange={setLongHours} />
      </div>

      <div className="rounded-xl p-4 mb-3" style={{ background: C.surface, border: `1px solid ${C.border}` }}>
        <p className="text-sm mb-3" style={{ color: C.navy }}>
          How best would you deal with clients making you feel uncomfortable?
        </p>
        <textarea
          value={uncomfortableAnswer}
          onChange={(e) => setUncomfortableAnswer(e.target.value)}
          rows={5}
          className="w-full px-3 py-2 rounded-lg text-sm"
          style={{ background: "#F7F4EC", color: C.navy, border: `1px solid ${C.border}` }}
        />
        <p className="text-xs mt-1" style={{ color: uncomfortableWords > WORD_LIMIT ? C.warn : C.navyDim }}>
          {uncomfortableWords} / {WORD_LIMIT} words
        </p>
      </div>

      <div className="rounded-xl p-4 mb-8" style={{ background: C.surface, border: `1px solid ${C.border}` }}>
        <p className="text-sm mb-3" style={{ color: C.navy }}>
          How best would you deal with clients who will want you to join them for drinks during working hours?
        </p>
        <textarea
          value={drinksAnswer}
          onChange={(e) => setDrinksAnswer(e.target.value)}
          rows={5}
          className="w-full px-3 py-2 rounded-lg text-sm"
          style={{ background: "#F7F4EC", color: C.navy, border: `1px solid ${C.border}` }}
        />
        <p className="text-xs mt-1" style={{ color: drinksWords > WORD_LIMIT ? C.warn : C.navyDim }}>
          {drinksWords} / {WORD_LIMIT} words
        </p>
      </div>

      {error && <p className="text-xs mb-3" style={{ color: C.warn }}>{error}</p>}

      <button
        onClick={submit}
        disabled={saving || !allAnswered}
        className="text-sm font-semibold px-6 py-3 rounded-full disabled:opacity-50"
        style={{ background: C.wood, color: "#FFFFFF" }}
      >
        {saving ? "Saving…" : "Save answers"}
      </button>
      {saved && <span className="text-xs ml-3" style={{ color: C.ok }}>Saved</span>}
    </div>
  );
}
