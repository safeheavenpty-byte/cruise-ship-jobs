import Link from "next/link";
import { FileText, Languages, Award, Stethoscope, ShieldCheck } from "lucide-react";

const C = { surface: "#FFFFFF", wood: "#A97C50", navy: "#0B2942", navyDim: "#5B7286", border: "#E3DCC9" };

const CHECKLIST = [
  { icon: FileText, label: "CV / Résumé" },
  { icon: Languages, label: "Language Accreditation", note: "TOEFL, IELTS, TOEIC, Cambridge, or JLPT only" },
  { icon: Award, label: "Qualification Certificates" },
  { icon: Stethoscope, label: "Medical Exam Results" },
  { icon: ShieldCheck, label: "Police Clearance Certificate" },
];

export default function WelcomePage() {
  return (
    <div className="max-w-lg">
      <p className="text-xs mb-1" style={{ color: C.wood, fontFamily: "monospace" }}>REGISTRATION COMPLETE</p>
      <h1 className="text-3xl mb-3" style={{ color: C.navy, fontFamily: "serif" }}>Thank you for registering!</h1>
      <p className="text-sm mb-8" style={{ color: C.navyDim }}>
        Please proceed to submitting the following documents to finish your application. Each one is
        reviewed by our team — you'll see the status update right here as it moves along.
      </p>

      <div className="rounded-xl p-5 mb-8" style={{ background: C.surface, border: `1px solid ${C.border}` }}>
        <div className="space-y-4">
          {CHECKLIST.map(({ icon: Icon, label, note }) => (
            <div key={label} className="flex items-start gap-3">
              <div
                className="w-9 h-9 rounded-full flex items-center justify-center shrink-0"
                style={{ background: "#F7F4EC", border: `1px solid ${C.border}` }}
              >
                <Icon size={16} style={{ color: C.wood }} />
              </div>
              <div>
                <p className="text-sm" style={{ color: C.navy }}>{label}</p>
                {note && <p className="text-xs mt-0.5" style={{ color: C.navyDim }}>{note}</p>}
              </div>
            </div>
          ))}
        </div>
        <p className="text-[11px] mt-5 pt-4" style={{ color: C.navyDim, borderTop: `1px solid ${C.border}` }}>
          Accepted formats: DOC, DOCX, PDF, TXT — 3MB maximum per file.
        </p>
      </div>

      <Link
        href="/app/documents"
        className="inline-block text-sm font-semibold px-6 py-3 rounded-full"
        style={{ background: C.wood, color: "#FFFFFF" }}
      >
        Submit my documents
      </Link>
    </div>
  );
}
