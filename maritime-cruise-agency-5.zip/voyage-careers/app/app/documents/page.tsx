"use client";

import { useEffect, useState } from "react";
import { createClient } from "@/lib/supabase/client";
import type { DocumentType, DocumentStatus, LanguageTestType } from "@/types/database";

const C = { surface: "#FFFFFF", gold: "#A97C50", paper: "#0B2942", paperDim: "#5B7286", hairline: "#E3DCC9", ok: "#4F8B6E", warn: "#B5651D" };

const DOC_TYPES: { id: DocumentType; label: string }[] = [
  { id: "cv", label: "CV / Résumé" },
  { id: "language_accreditation", label: "Language Accreditation" },
  { id: "certificate", label: "Qualification Certificates" },
  { id: "medical_exam", label: "Medical Exam Results" },
  { id: "police_clearance", label: "Police Clearance Certificate" },
];

const LANGUAGE_TESTS: LanguageTestType[] = ["TOEFL", "IELTS", "TOEIC", "Cambridge", "JLPT"];

const ACCEPTED_EXTENSIONS = [".doc", ".docx", ".pdf", ".txt"];
const ACCEPTED_MIME = [
  "application/msword",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  "application/pdf",
  "text/plain",
];
const MAX_BYTES = 3 * 1024 * 1024; // 3MB

type DocRecord = { id: string; type: DocumentType; status: DocumentStatus; test_type: LanguageTestType | null };

function validateFile(file: File): string | null {
  const ext = "." + file.name.split(".").pop()?.toLowerCase();
  const typeOk = ACCEPTED_MIME.includes(file.type) || ACCEPTED_EXTENSIONS.includes(ext);
  if (!typeOk) return "Only DOC, DOCX, PDF, or TXT files are accepted.";
  if (file.size > MAX_BYTES) return "File must be 3MB or smaller.";
  return null;
}

export default function DocumentsPage() {
  const supabase = createClient();
  const [docs, setDocs] = useState<Record<string, DocRecord>>({});
  const [uploading, setUploading] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [userId, setUserId] = useState<string | null>(null);
  const [testType, setTestType] = useState<LanguageTestType>("IELTS");

  async function load() {
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) return;
    setUserId(user.id);
    const { data } = await supabase.from("documents").select("id, type, status, test_type").eq("applicant_id", user.id);
    const byType: Record<string, DocRecord> = {};
    (data ?? []).forEach((d) => { byType[d.type] = d as DocRecord; });
    setDocs(byType);
  }

  useEffect(() => { load(); }, []);

  async function handleUpload(type: DocumentType, file: File) {
    if (!userId) return;
    setError(null);

    const validationError = validateFile(file);
    if (validationError) {
      setError(validationError);
      return;
    }

    setUploading(type);

    const path = `${userId}/${type}/${Date.now()}-${file.name}`;
    const { error: uploadError } = await supabase.storage.from("documents").upload(path, file);
    if (uploadError) {
      setError(uploadError.message);
      setUploading(null);
      return;
    }

    const extra = type === "language_accreditation" ? { test_type: testType } : {};
    const existing = docs[type];
    const { error: writeError } = existing
      ? await supabase
          .from("documents")
          .update({ file_path: path, status: "submitted", reviewed_at: null, reviewed_by: null, review_notes: null, ...extra })
          .eq("id", existing.id)
      : await supabase
          .from("documents")
          .insert({ applicant_id: userId, type, file_path: path, status: "submitted", ...extra });

    if (writeError) setError(writeError.message);
    await load();
    setUploading(null);
  }

  const approvedCount = Object.values(docs).filter((d) => d.status === "approved").length;

  return (
    <div>
      <p className="text-xs mb-1" style={{ color: C.gold, fontFamily: "monospace" }}>DOCUMENT WALLET</p>
      <h1 className="text-3xl mb-2" style={{ color: C.paper, fontFamily: "serif" }}>Submit your paperwork</h1>
      <p className="text-sm mb-1" style={{ color: C.paperDim }}>{approvedCount} of {DOC_TYPES.length} documents approved</p>
      <p className="text-xs mb-8" style={{ color: C.paperDim }}>Accepted formats: DOC, DOCX, PDF, TXT — 3MB maximum per file.</p>

      {error && <p className="text-xs mb-4" style={{ color: C.warn }}>{error}</p>}

      <div className="space-y-3">
        {DOC_TYPES.map((doc) => {
          const record = docs[doc.id];
          const status: DocumentStatus | "not_submitted" = record?.status ?? "not_submitted";
          const statusColor = status === "approved" ? C.ok : status === "rejected" ? C.warn : C.gold;
          return (
            <div key={doc.id} className="rounded-xl p-4 flex items-center justify-between gap-4 flex-wrap" style={{ background: C.surface, border: `1px solid ${C.hairline}` }}>
              <div>
                <p className="text-sm" style={{ color: C.paper }}>{doc.label}</p>
                <p className="text-xs mt-1" style={{ color: statusColor }}>
                  {status.replace("_", " ")}
                  {doc.id === "language_accreditation" && record?.test_type ? ` · ${record.test_type}` : ""}
                </p>
                {doc.id === "language_accreditation" && (
                  <p className="text-[11px] mt-1" style={{ color: C.paperDim }}>Only TOEFL, IELTS, TOEIC, Cambridge, or JLPT results are recognized.</p>
                )}
              </div>

              <div className="flex items-center gap-2 shrink-0">
                {doc.id === "language_accreditation" && (
                  <select
                    value={testType}
                    onChange={(e) => setTestType(e.target.value as LanguageTestType)}
                    className="text-xs px-2 py-2 rounded-lg"
                    style={{ background: "#F7F4EC", color: C.paper, border: `1px solid ${C.hairline}` }}
                  >
                    {LANGUAGE_TESTS.map((t) => <option key={t} value={t}>{t}</option>)}
                  </select>
                )}
                <label
                  className="text-xs font-semibold px-3 py-2 rounded-full cursor-pointer"
                  style={{ background: C.gold, color: "#0B2942", opacity: uploading === doc.id ? 0.5 : 1 }}
                >
                  {uploading === doc.id ? "Uploading…" : record ? "Replace file" : "Upload"}
                  <input
                    type="file"
                    accept=".doc,.docx,.pdf,.txt"
                    className="hidden"
                    disabled={uploading === doc.id}
                    onChange={(e) => e.target.files?.[0] && handleUpload(doc.id, e.target.files[0])}
                  />
                </label>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
