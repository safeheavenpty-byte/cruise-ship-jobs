import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import ScamNotice from "@/components/ScamNotice";

const C = { surface: "#FFFFFF", gold: "#A97C50", paper: "#0B2942", paperDim: "#5B7286", hairline: "#E3DCC9" };

const STEPS = ["submitted", "exam_pending", "documents_pending", "under_review", "approved"];

export default async function ApplicantDashboard() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  const [{ count: approvedDocs }, { data: exams }, { data: applications }] = await Promise.all([
    supabase.from("documents").select("*", { count: "exact", head: true }).eq("applicant_id", user!.id).eq("status", "approved"),
    supabase.from("exam_results").select("category, passed").eq("applicant_id", user!.id),
    supabase.from("applications").select("stage").eq("applicant_id", user!.id),
  ]);

  const passedExams = new Set((exams ?? []).filter((e) => e.passed).map((e) => e.category)).size;
  const furthestStage = applications?.length
    ? Math.max(...applications.map((a) => STEPS.indexOf(a.stage)).filter((i) => i >= 0))
    : -1;

  return (
    <div>
      <p className="text-xs mb-1" style={{ color: C.gold, fontFamily: "monospace" }}>APPLICANT OVERVIEW</p>
      <h1 className="text-3xl mb-4" style={{ color: C.paper, fontFamily: "serif" }}>Welcome back.</h1>

      <div className="mb-8"><ScamNotice compact /></div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-10">
        <Link href="/app/documents" className="rounded-xl p-5 block" style={{ background: C.surface, border: `1px solid ${C.hairline}` }}>
          <div className="text-3xl mb-2" style={{ color: C.paper, fontFamily: "serif" }}>{approvedDocs ?? 0} / 4</div>
          <div className="text-xs" style={{ color: C.paperDim }}>Documents approved</div>
        </Link>
        <Link href="/app/exams" className="rounded-xl p-5 block" style={{ background: C.surface, border: `1px solid ${C.hairline}` }}>
          <div className="text-3xl mb-2" style={{ color: C.paper, fontFamily: "serif" }}>{passedExams} / 3</div>
          <div className="text-xs" style={{ color: C.paperDim }}>Exams passed</div>
        </Link>
        <Link href="/app/jobs" className="rounded-xl p-5 block" style={{ background: C.surface, border: `1px solid ${C.hairline}` }}>
          <div className="text-3xl mb-2" style={{ color: C.paper, fontFamily: "serif" }}>{applications?.length ?? 0}</div>
          <div className="text-xs" style={{ color: C.paperDim }}>Active applications</div>
        </Link>
      </div>

      <div className="rounded-xl p-6" style={{ background: C.surface, border: `1px solid ${C.hairline}` }}>
        <p className="text-xs mb-4" style={{ color: C.gold, fontFamily: "monospace" }}>BOARDING PASS · YOUR JOURNEY</p>
        <div className="flex items-center">
          {["Applied", "Exam", "Documents", "Review", "Approved"].map((label, i) => (
            <div key={label} className="flex-1 flex flex-col items-center">
              <div
                className="w-8 h-8 rounded-full flex items-center justify-center text-xs"
                style={{
                  border: `1.5px solid ${C.gold}`,
                  color: i <= furthestStage ? "#0B2942" : C.gold,
                  background: i <= furthestStage ? C.gold : "transparent",
                }}
              >
                {i + 1}
              </div>
              <span className="text-xs mt-2" style={{ color: C.paperDim }}>{label}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
