"use client";

import { useEffect, useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { verifyEmployment } from "@/lib/actions/applicant";
import type { Ship } from "@/types/database";

const C = { surface: "#FFFFFF", wood: "#A97C50", navy: "#0B2942", navyDim: "#5B7286", border: "#E3DCC9", ok: "#4F8B6E" };

const STAGE_LABEL: Record<string, string> = {
  submitted: "Submitted",
  exam_pending: "Exam pending",
  documents_pending: "Documents pending",
  under_review: "Under review",
  approved: "Approved",
  rejected: "Rejected",
};

type AppRow = {
  id: string;
  stage: string;
  employee_number: string | null;
  ship_id: string | null;
  verified_at: string | null;
  jobs: { title: string; line: string | null; category: string } | null;
};

function VerifyForm({ application, ships, onDone }: { application: AppRow; ships: Ship[]; onDone: () => void }) {
  const [employeeNumber, setEmployeeNumber] = useState("");
  const [shipId, setShipId] = useState("");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setSaving(true);
    try {
      await verifyEmployment(application.id, employeeNumber.trim(), shipId);
      onDone();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <form onSubmit={submit} className="mt-3 pt-3 space-y-2" style={{ borderTop: `1px solid ${C.border}` }}>
      <p className="text-xs" style={{ color: C.navyDim }}>
        Received your employee number and ship assignment from HR? Enter them here to confirm.
      </p>
      <div className="grid grid-cols-2 gap-2">
        <input
          placeholder="Employee number"
          value={employeeNumber}
          onChange={(e) => setEmployeeNumber(e.target.value)}
          required
          className="px-3 py-2 rounded-lg text-sm"
          style={{ background: "#F7F4EC", color: C.navy, border: `1px solid ${C.border}` }}
        />
        <select
          value={shipId}
          onChange={(e) => setShipId(e.target.value)}
          required
          className="px-3 py-2 rounded-lg text-sm"
          style={{ background: "#F7F4EC", color: C.navy, border: `1px solid ${C.border}` }}
        >
          <option value="" disabled>Select ship</option>
          {ships.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
        </select>
      </div>
      {error && <p className="text-xs" style={{ color: "#B5651D" }}>{error}</p>}
      <button
        type="submit"
        disabled={saving}
        className="text-xs font-semibold px-4 py-2 rounded-full disabled:opacity-50"
        style={{ background: C.wood, color: "#FFFFFF" }}
      >
        {saving ? "Confirming…" : "Confirm"}
      </button>
    </form>
  );
}

export default function MyApplicationsPage() {
  const supabase = createClient();
  const [applications, setApplications] = useState<AppRow[]>([]);
  const [ships, setShips] = useState<Ship[]>([]);
  const [loading, setLoading] = useState(true);

  async function load() {
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) return;

    const [{ data: apps }, { data: shipRows }] = await Promise.all([
      supabase
        .from("applications")
        .select("id, stage, employee_number, ship_id, verified_at, jobs:job_id (title, line, category)")
        .eq("applicant_id", user.id)
        .order("created_at", { ascending: false }),
      supabase.from("ships").select("*").eq("is_active", true).order("name"),
    ]);

    setApplications((apps ?? []) as unknown as AppRow[]);
    setShips((shipRows ?? []) as Ship[]);
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  function shipName(id: string | null) {
    return ships.find((s) => s.id === id)?.name ?? null;
  }

  return (
    <div>
      <p className="text-xs mb-1" style={{ color: C.wood, fontFamily: "monospace" }}>MY APPLICATIONS</p>
      <h1 className="text-3xl mb-8" style={{ color: C.navy, fontFamily: "serif" }}>Your job applications</h1>

      {loading ? (
        <p className="text-sm" style={{ color: C.navyDim }}>Loading…</p>
      ) : applications.length === 0 ? (
        <p className="text-sm" style={{ color: C.navyDim }}>You haven't applied to any roles yet.</p>
      ) : (
        <div className="space-y-4">
          {applications.map((app) => (
            <div key={app.id} className="rounded-xl p-4" style={{ background: C.surface, border: `1px solid ${C.border}` }}>
              <div className="flex justify-between items-start flex-wrap gap-2">
                <div>
                  <p className="text-sm" style={{ color: C.navy }}>{app.jobs?.title ?? "Role"}</p>
                  <p className="text-xs mt-0.5" style={{ color: C.navyDim }}>{app.jobs?.line}</p>
                </div>
                <span
                  className="text-xs font-semibold px-3 py-1.5 rounded-full"
                  style={{ background: app.verified_at ? C.ok : "#F7F4EC", color: app.verified_at ? "#FFFFFF" : C.navyDim, border: app.verified_at ? "none" : `1px solid ${C.border}` }}
                >
                  {STAGE_LABEL[app.stage] ?? app.stage}
                </span>
              </div>

              {app.verified_at ? (
                <div className="mt-3 pt-3" style={{ borderTop: `1px solid ${C.border}` }}>
                  <p className="text-sm" style={{ color: C.ok, fontFamily: "serif" }}>
                    Verified &amp; Approved — Awaiting visa submission
                  </p>
                  <p className="text-xs mt-1" style={{ color: C.navyDim }}>
                    Employee #{app.employee_number} · {shipName(app.ship_id) ?? "Ship assigned"}
                  </p>
                </div>
              ) : (
                <VerifyForm application={app} ships={ships} onDone={load} />
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
