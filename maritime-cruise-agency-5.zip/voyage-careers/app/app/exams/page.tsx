"use client";

import { useEffect, useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { submitExamResult } from "@/lib/actions/applicant";
import { EXAMS } from "@/lib/data/exams";
import type { JobCategory } from "@/types/database";

const C = { surface: "#FFFFFF", gold: "#A97C50", paper: "#0B2942", paperDim: "#5B7286", hairline: "#E3DCC9", ok: "#4F8B6E", warn: "#B5651D" };
const CATEGORIES: JobCategory[] = ["cruise", "hospitality", "healthcare"];

export default function ExamsPage() {
  const supabase = createClient();
  const [results, setResults] = useState<Record<string, { score: number; passed: boolean }>>({});
  const [activeCat, setActiveCat] = useState<JobCategory | null>(null);
  const [answers, setAnswers] = useState<Record<number, number>>({});
  const [lastResult, setLastResult] = useState<{ score: number; passed: boolean } | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (!user) return;
      const { data } = await supabase
        .from("exam_results")
        .select("category, score, passed")
        .eq("applicant_id", user.id)
        .order("taken_at", { ascending: false });

      const latest: Record<string, { score: number; passed: boolean }> = {};
      (data ?? []).forEach((r) => {
        if (!latest[r.category]) latest[r.category] = { score: r.score, passed: r.passed };
      });
      setResults(latest);
      setLoading(false);
    })();
  }, []);

  function start(cat: JobCategory) {
    setActiveCat(cat);
    setAnswers({});
    setLastResult(null);
  }

  async function submit() {
    if (!activeCat) return;
    const exam = EXAMS[activeCat];
    const correct = exam.questions.filter((q, i) => answers[i] === q.answer).length;
    const score = Math.round((correct / exam.questions.length) * 100);
    const passed = score >= 70;
    await submitExamResult(activeCat, score, passed);
    setResults((prev) => ({ ...prev, [activeCat]: { score, passed } }));
    setLastResult({ score, passed });
  }

  if (loading) return <p className="text-sm" style={{ color: C.paperDim }}>Loading…</p>;

  if (activeCat) {
    const exam = EXAMS[activeCat];
    return (
      <div className="max-w-2xl">
        <button onClick={() => setActiveCat(null)} className="text-xs mb-4" style={{ color: C.paperDim }}>
          ← Back to exams
        </button>
        <h1 className="text-2xl mb-6" style={{ color: C.paper, fontFamily: "serif" }}>{exam.title}</h1>

        {!lastResult ? (
          <div className="space-y-6">
            {exam.questions.map((q, qi) => (
              <div key={qi} className="rounded-xl p-5" style={{ background: C.surface, border: `1px solid ${C.hairline}` }}>
                <p className="text-sm mb-3" style={{ color: C.paper }}>{qi + 1}. {q.q}</p>
                <div className="space-y-2">
                  {q.options.map((opt, oi) => (
                    <label key={oi} className="flex items-center gap-2 text-sm cursor-pointer" style={{ color: C.paperDim }}>
                      <input
                        type="radio"
                        name={`q${qi}`}
                        checked={answers[qi] === oi}
                        onChange={() => setAnswers((a) => ({ ...a, [qi]: oi }))}
                        style={{ accentColor: C.gold }}
                      />
                      {opt}
                    </label>
                  ))}
                </div>
              </div>
            ))}
            <button
              onClick={submit}
              disabled={Object.keys(answers).length < exam.questions.length}
              className="text-sm font-semibold px-5 py-2.5 rounded-full disabled:opacity-40"
              style={{ background: C.gold, color: "#0B2942" }}
            >
              Submit exam
            </button>
          </div>
        ) : (
          <div className="rounded-xl p-6 text-center" style={{ background: C.surface, border: `1px solid ${C.hairline}` }}>
            <div
              className="w-20 h-20 rounded-full mx-auto flex items-center justify-center text-2xl mb-4"
              style={{ border: `2px solid ${lastResult.passed ? C.ok : C.warn}`, color: lastResult.passed ? C.ok : C.warn, fontFamily: "serif" }}
            >
              {lastResult.score}%
            </div>
            <p className="text-lg" style={{ color: C.paper, fontFamily: "serif" }}>{lastResult.passed ? "Passed" : "Not yet a pass"}</p>
            <p className="text-xs mt-1" style={{ color: C.paperDim }}>
              {lastResult.passed ? "This result has been added to your record." : "You need 70% or higher. You can retake any time."}
            </p>
            <button onClick={() => setActiveCat(null)} className="text-sm mt-5 underline" style={{ color: C.gold }}>
              Return to exams
            </button>
          </div>
        )}
      </div>
    );
  }

  return (
    <div>
      <p className="text-xs mb-1" style={{ color: C.gold, fontFamily: "monospace" }}>ONLINE ASSESSMENTS</p>
      <h1 className="text-3xl mb-8" style={{ color: C.paper, fontFamily: "serif" }}>Take your qualifying exam</h1>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {CATEGORIES.map((cat) => {
          const result = results[cat];
          return (
            <div key={cat} className="rounded-xl p-5" style={{ background: C.surface, border: `1px solid ${C.hairline}` }}>
              <h3 className="text-lg" style={{ color: C.paper, fontFamily: "serif" }}>{EXAMS[cat].title}</h3>
              <p className="text-xs mt-1 mb-3" style={{ color: C.paperDim }}>{EXAMS[cat].questions.length} questions · 70% to pass</p>
              <a
                href={`/api/exams/${cat}/file`}
                target="_blank"
                rel="noreferrer"
                className="text-xs underline block mb-4"
                style={{ color: C.gold }}
              >
                Download exam PDF
              </a>
              {result ? (
                <div className="flex items-center justify-between">
                  <span className="text-xs" style={{ color: result.passed ? C.ok : C.warn }}>
                    {result.passed ? "Passed" : `${result.score}%`}
                  </span>
                  <button onClick={() => start(cat)} className="text-xs underline" style={{ color: C.gold }}>Retake</button>
                </div>
              ) : (
                <button onClick={() => start(cat)} className="text-xs font-semibold px-4 py-2 rounded-full" style={{ background: C.gold, color: "#0B2942" }}>
                  Start exam
                </button>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
