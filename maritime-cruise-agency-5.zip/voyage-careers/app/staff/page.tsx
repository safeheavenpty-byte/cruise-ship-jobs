import Link from "next/link";
import { createClient } from "@/lib/supabase/server";

const C = { surface: "#FFFFFF", gold: "#A97C50", paper: "#0B2942", paperDim: "#5B7286", hairline: "#E3DCC9" };

export default async function StaffOverview() {
  const supabase = await createClient();

  const [{ count: pendingDocs }, { count: pendingApps }, { count: pendingTravel }] = await Promise.all([
    supabase.from("documents").select("*", { count: "exact", head: true }).eq("status", "submitted"),
    supabase.from("applications").select("*", { count: "exact", head: true }).eq("stage", "submitted"),
    supabase.from("travel_requests").select("*", { count: "exact", head: true }).eq("status", "requested"),
  ]);

  const cards = [
    { label: "Documents awaiting review", value: pendingDocs ?? 0, href: "/staff/documents" },
    { label: "Applications awaiting review", value: pendingApps ?? 0, href: "/staff/applications" },
    { label: "Travel requests awaiting action", value: pendingTravel ?? 0, href: "/staff/travel" },
  ];

  return (
    <div>
      <p className="text-xs mb-1" style={{ color: C.gold, fontFamily: "monospace" }}>STAFF CONSOLE</p>
      <h1 className="text-3xl mb-8" style={{ color: C.paper, fontFamily: "serif" }}>What needs your attention</h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {cards.map((c) => (
          <Link
            key={c.href}
            href={c.href}
            className="rounded-xl p-5 block"
            style={{ background: C.surface, border: `1px solid ${C.hairline}` }}
          >
            <div className="text-3xl mb-2" style={{ color: C.paper, fontFamily: "serif" }}>{c.value}</div>
            <div className="text-xs" style={{ color: C.paperDim }}>{c.label}</div>
          </Link>
        ))}
      </div>
    </div>
  );
}
