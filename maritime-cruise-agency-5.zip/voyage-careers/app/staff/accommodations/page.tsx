"use client";

import { useEffect, useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { createAccommodation, toggleAccommodationAvailable } from "@/lib/actions/staff";
import type { Accommodation } from "@/types/database";

const C = { ink: "#F7F4EC", surface: "#FFFFFF", surface2: "#FBF8F1", gold: "#A97C50", paper: "#0B2942", paperDim: "#5B7286", hairline: "#E3DCC9", ok: "#4F8B6E" };

export default function StaffAccommodationsPage() {
  const supabase = createClient();
  const [listings, setListings] = useState<Accommodation[]>([]);
  const [loading, setLoading] = useState(true);
  const [formOpen, setFormOpen] = useState(false);

  // form state
  const [title, setTitle] = useState("");
  const [location, setLocation] = useState("");
  const [description, setDescription] = useState("");
  const [priceInfo, setPriceInfo] = useState("");
  const [files, setFiles] = useState<File[]>([]);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function load() {
    const { data } = await supabase.from("accommodations").select("*").order("created_at", { ascending: false });
    setListings((data ?? []) as Accommodation[]);
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  function photoUrl(path: string) {
    return supabase.storage.from("accommodation-photos").getPublicUrl(path).data.publicUrl;
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setSaving(true);

    try {
      const paths: string[] = [];
      for (const file of files) {
        const path = `${Date.now()}-${file.name}`;
        const { error: uploadError } = await supabase.storage.from("accommodation-photos").upload(path, file);
        if (uploadError) throw new Error(uploadError.message);
        paths.push(path);
      }
      await createAccommodation({ title, location, description, price_info: priceInfo, photo_paths: paths });
      setTitle(""); setLocation(""); setDescription(""); setPriceInfo(""); setFiles([]);
      setFormOpen(false);
      await load();
    } catch (e: any) {
      setError(e.message);
    } finally {
      setSaving(false);
    }
  }

  function toggle(listing: Accommodation) {
    toggleAccommodationAvailable(listing.id, !listing.is_available).then(load);
  }

  return (
    <div>
      <p className="text-xs mb-1" style={{ color: C.gold, fontFamily: "monospace" }}>ACCOMMODATION LISTINGS</p>
      <h1 className="text-3xl mb-6" style={{ color: C.paper, fontFamily: "serif" }}>Places available for booking</h1>

      {!formOpen ? (
        <button
          onClick={() => setFormOpen(true)}
          className="text-xs font-semibold px-4 py-2 rounded-full mb-6"
          style={{ background: C.gold, color: "#0B2942" }}
        >
          + Post a new listing
        </button>
      ) : (
        <form onSubmit={submit} className="rounded-xl p-5 mb-6 space-y-3" style={{ background: C.surface2, border: `1px solid ${C.hairline}` }}>
          {error && <p className="text-xs" style={{ color: "#B5651D" }}>{error}</p>}
          <input
            placeholder="Title (e.g. Crew House — Southampton)"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            required
            className="w-full px-3 py-2 rounded-lg text-sm"
            style={{ background: C.ink, color: C.paper, border: `1px solid ${C.hairline}` }}
          />
          <input
            placeholder="Location"
            value={location}
            onChange={(e) => setLocation(e.target.value)}
            className="w-full px-3 py-2 rounded-lg text-sm"
            style={{ background: C.ink, color: C.paper, border: `1px solid ${C.hairline}` }}
          />
          <textarea
            placeholder="Description (rooms, amenities, distance to port/site, etc.)"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            rows={3}
            className="w-full px-3 py-2 rounded-lg text-sm"
            style={{ background: C.ink, color: C.paper, border: `1px solid ${C.hairline}` }}
          />
          <input
            placeholder="Price info (e.g. Included in contract / $150/week)"
            value={priceInfo}
            onChange={(e) => setPriceInfo(e.target.value)}
            className="w-full px-3 py-2 rounded-lg text-sm"
            style={{ background: C.ink, color: C.paper, border: `1px solid ${C.hairline}` }}
          />
          <label className="block text-xs" style={{ color: C.paperDim }}>
            Photos
            <input
              type="file"
              accept="image/*"
              multiple
              onChange={(e) => setFiles(Array.from(e.target.files ?? []))}
              className="block mt-1 text-xs"
              style={{ color: C.paperDim }}
            />
          </label>
          {files.length > 0 && <p className="text-xs" style={{ color: C.paperDim }}>{files.length} photo(s) selected</p>}

          <div className="flex gap-2">
            <button
              type="submit"
              disabled={saving}
              className="text-xs font-semibold px-4 py-2 rounded-full disabled:opacity-50"
              style={{ background: C.gold, color: "#0B2942" }}
            >
              {saving ? "Posting…" : "Post listing"}
            </button>
            <button type="button" onClick={() => setFormOpen(false)} className="text-xs px-4 py-2" style={{ color: C.paperDim }}>
              Cancel
            </button>
          </div>
        </form>
      )}

      {loading ? (
        <p className="text-sm" style={{ color: C.paperDim }}>Loading…</p>
      ) : listings.length === 0 ? (
        <p className="text-sm" style={{ color: C.paperDim }}>No accommodation listings posted yet.</p>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {listings.map((listing) => (
            <div key={listing.id} className="rounded-xl overflow-hidden" style={{ background: C.surface, border: `1px solid ${C.hairline}` }}>
              {listing.photo_paths.length > 0 && (
                <div className="grid grid-cols-3 gap-0.5">
                  {listing.photo_paths.slice(0, 3).map((p) => (
                    <img key={p} src={photoUrl(p)} alt={listing.title} className="w-full h-24 object-cover" />
                  ))}
                </div>
              )}
              <div className="p-4">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-sm" style={{ color: C.paper }}>{listing.title}</p>
                    <p className="text-xs mt-0.5" style={{ color: C.paperDim }}>{listing.location}</p>
                  </div>
                  <button
                    onClick={() => toggle(listing)}
                    className="text-xs font-semibold px-3 py-1.5 rounded-full shrink-0"
                    style={{ background: listing.is_available ? C.ok : C.hairline, color: listing.is_available ? "#0B2942" : C.paperDim }}
                  >
                    {listing.is_available ? "Available" : "Unavailable"}
                  </button>
                </div>
                {listing.price_info && <p className="text-xs mt-2" style={{ color: C.gold }}>{listing.price_info}</p>}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
