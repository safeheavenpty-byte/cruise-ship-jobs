"use client";

import { useEffect, useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { createExamDocument } from "@/lib/actions/staff";
import type { JobCategory } from "@/types/database";

const C = { surface: "#FFFFFF", gold: "#A97C50", paper: "#0B2942", paperDim: "#5B7286", hairline: "#E3DCC9", ok: "#4F8B6E" };

const CATEGORIES: { id: JobCategory; label: string }[] = [
  { id: "cruise", label: "Cruise Ship" },
  { id: "hospitality", label: "Hospitality" },
  { id: "healthcare", label: "Healthcare" },
];

type Current = { title: string | null; created_at: string } | null;

export default function StaffExamsPage() {
  const supabase = createClient();
  const [current, setCurrent] = useState<Record<string, Current>>({});
  const [uploading, setUploading] = useState<JobCategory | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function load() {
    const { data } = await supabase
      .from("exam_documents")
      .select("category, title, created_at")
      .order("created_at", { ascending: false });
    const latest: Record<string, Current> = {};
    (data ?? []).forEach((d) => {
      if (!latest[d.category]) latest[d.category] = { title: d.title, created_at: d.created_at };
    });
    setCurrent(latest);
  }

  useEffect(() => { load(); }, []);

  async function handleUpload(category: JobCategory, file: File) {
    setError(null);
    setUploading(category);

    const path = `${category}/${Date.now()}-${file.name}`;
    const { error: uploadError } = await supabase.storage.from("exam-documents").upload(path, file);
    if (uploadError) {
      setError(uploadError.message);
      setUploading(null);
      return;
    }
    try {
      await createExamDocument(category, path, file.name);
    } catch (e: any) {
      setError(e.message);
    }
    await load();
    setUploading(null);
  }

  return (
    <div>
      <p className="text-xs mb-1" style={{ color: C.gold, fontFamily: "monospace" }}>EXAM MATERIALS</p>
      <h1 className="text-3xl mb-2" style={{ color: C.paper, fontFamily: "serif" }}>Post exam PDFs</h1>
      <p className="text-xs mb-8" style={{ color: C.paperDim }}>
        Upload the exam paper for each category as a PDF. Applicants always see the most recent upload.
      </p>

      {error && <p className="text-xs mb-4" style={{ color: "#B5651D" }}>{error}</p>}

      <div className="space-y-3">
        {CATEGORIES.map(({ id, label }) => {
          const doc = current[id];
          return (
            <div
              key={id}
              className="rounded-xl p-4 flex items-center justify-between gap-4 flex-wrap"
              style={{ background: C.surface, border: `1px solid ${C.hairline}` }}
            >
              <div>
                <p className="text-sm" style={{ color: C.paper }}>{label}</p>
                {doc ? (
                  <p className="text-xs mt-1" style={{ color: C.ok }}>
                    Current: {doc.title} · {new Date(doc.created_at).toLocaleDateString()}
                  </p>
                ) : (
                  <p className="text-xs mt-1" style={{ color: C.paperDim }}>No exam PDF posted yet</p>
                )}
              </div>
              <label
                className="text-xs font-semibold px-3 py-2 rounded-full cursor-pointer"
                style={{ background: C.gold, color: "#0B2942", opacity: uploading === id ? 0.5 : 1 }}
              >
                {uploading === id ? "Uploading…" : doc ? "Replace PDF" : "Upload PDF"}
                <input
                  type="file"
                  accept="application/pdf"
                  className="hidden"
                  disabled={uploading === id}
                  onChange={(e) => e.target.files?.[0] && handleUpload(id, e.target.files[0])}
                />
              </label>
            </div>
          );
        })}
      </div>
    </div>
  );
}
