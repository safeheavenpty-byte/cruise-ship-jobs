"use client";

import { useTransition } from "react";
import { updateApplicationStage } from "@/lib/actions/staff";
import type { ApplicationStage } from "@/types/database";

const C = { gold: "#A97C50", paper: "#0B2942", paperDim: "#5B7286", hairline: "#E3DCC9" };

const STAGES: ApplicationStage[] = [
  "submitted",
  "exam_pending",
  "documents_pending",
  "under_review",
  "approved",
  "rejected",
];

export default function ApplicationRow({
  id,
  applicantName,
  jobTitle,
  stage,
}: {
  id: string;
  applicantName: string;
  jobTitle: string;
  stage: ApplicationStage;
}) {
  const [isPending, startTransition] = useTransition();

  return (
    <div
      className="rounded-xl p-4 flex items-center justify-between gap-4 flex-wrap"
      style={{ background: "#FBF8F1", border: `1px solid ${C.hairline}` }}
    >
      <div>
        <p className="text-sm" style={{ color: C.paper }}>{jobTitle}</p>
        <p className="text-xs mt-0.5" style={{ color: C.paperDim }}>{applicantName}</p>
      </div>
      <select
        disabled={isPending}
        defaultValue={stage}
        onChange={(e) => startTransition(() => updateApplicationStage(id, e.target.value as ApplicationStage))}
        className="text-xs px-3 py-2 rounded-full"
        style={{ background: "#FFFFFF", color: C.gold, border: `1px solid ${C.hairline}` }}
      >
        {STAGES.map((s) => (
          <option key={s} value={s}>
            {s.replace("_", " ")}
          </option>
        ))}
      </select>
    </div>
  );
}
