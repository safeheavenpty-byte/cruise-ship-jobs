import { createClient } from "@/lib/supabase/server";
import ApplicationRow from "./ApplicationRow";

const C = { gold: "#A97C50", paper: "#0B2942", paperDim: "#5B7286" };

export default async function StaffApplicationsPage() {
  const supabase = await createClient();

  const { data: applications } = await supabase
    .from("applications")
    .select("*, profiles:applicant_id (full_name), jobs:job_id (title)")
    .order("created_at", { ascending: true });

  return (
    <div>
      <p className="text-xs mb-1" style={{ color: C.gold, fontFamily: "monospace" }}>APPLICATIONS</p>
      <h1 className="text-3xl mb-6" style={{ color: C.paper, fontFamily: "serif" }}>All applications</h1>

      {!applications || applications.length === 0 ? (
        <p className="text-sm" style={{ color: C.paperDim }}>No applications yet.</p>
      ) : (
        <div className="space-y-3">
          {applications.map((a: any) => (
            <ApplicationRow
              key={a.id}
              id={a.id}
              applicantName={a.profiles?.full_name ?? "Unknown applicant"}
              jobTitle={a.jobs?.title ?? "Unknown role"}
              stage={a.stage}
            />
          ))}
        </div>
      )}
    </div>
  );
}
