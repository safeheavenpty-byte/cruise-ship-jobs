import { redirect } from "next/navigation";
import Link from "next/link";
import { getProfile } from "@/lib/supabase/server";

const C = { bg: "#F7F4EC", navy: "#0B2942", wood: "#A97C50", light: "#B7C4D1", border: "#E3DCC9" };

const NAV = [
  { href: "/staff", label: "Overview" },
  { href: "/staff/applications", label: "Applications" },
  { href: "/staff/documents", label: "Documents" },
  { href: "/staff/exams", label: "Exam PDFs" },
  { href: "/staff/screening", label: "Screening" },
  { href: "/staff/accommodations", label: "Accommodations" },
  { href: "/staff/ships", label: "Ships" },
  { href: "/staff/travel", label: "Visa & Travel" },
  { href: "/staff/inquiries", label: "Inquiries" },
];

export default async function StaffLayout({ children }: { children: React.ReactNode }) {
  // Middleware already redirects non-staff away from /staff, but we
  // double check here since layouts can be reached during data revalidation.
  const profile = await getProfile();
  if (!profile || profile.role !== "staff") redirect("/login");

  return (
    <div className="min-h-screen flex" style={{ background: C.bg }}>
      <aside className="w-60 shrink-0 hidden md:flex flex-col" style={{ background: C.navy }}>
        <div className="px-6 py-6" style={{ borderBottom: "1px solid rgba(255,255,255,0.1)" }}>
          <p className="text-sm" style={{ color: C.wood, fontFamily: "serif" }}>Maritime Cruise Agency</p>
          <p className="text-xs" style={{ color: C.light }}>Staff review console</p>
        </div>
        <nav className="flex-1 px-3 py-4 space-y-1">
          {NAV.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="block px-3 py-2.5 rounded-lg text-sm"
              style={{ color: C.light }}
            >
              {item.label}
            </Link>
          ))}
        </nav>
        <div className="px-6 py-4 text-xs" style={{ color: C.light, borderTop: "1px solid rgba(255,255,255,0.1)" }}>
          {profile.full_name ?? "Staff member"}
        </div>
      </aside>
      <main className="flex-1 p-6 md:p-10 max-w-5xl mx-auto w-full">{children}</main>
    </div>
  );
}
