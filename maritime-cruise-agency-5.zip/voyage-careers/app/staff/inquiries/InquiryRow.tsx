"use client";

import { useState, useTransition } from "react";
import { replyToInquiry } from "@/lib/actions/inquiries";
import type { Inquiry, InquiryStatus } from "@/types/database";

const C = { gold: "#A97C50", paper: "#0B2942", paperDim: "#5B7286", hairline: "#E3DCC9", ok: "#4F8B6E" };

const STATUSES: InquiryStatus[] = ["new", "in_progress", "resolved"];

export default function InquiryRow({ inquiry }: { inquiry: Inquiry }) {
  const [reply, setReply] = useState(inquiry.staff_reply ?? "");
  const [status, setStatus] = useState<InquiryStatus>(inquiry.status);
  const [isPending, startTransition] = useTransition();
  const [saved, setSaved] = useState(false);

  function save() {
    startTransition(async () => {
      await replyToInquiry(inquiry.id, reply, status);
      setSaved(true);
      setTimeout(() => setSaved(false), 1500);
    });
  }

  return (
    <div className="rounded-xl p-4" style={{ background: "#FBF8F1", border: `1px solid ${C.hairline}` }}>
      <div className="flex justify-between items-start mb-2 flex-wrap gap-2">
        <div>
          <p className="text-sm" style={{ color: C.paper }}>{inquiry.name}</p>
          <p className="text-xs mt-0.5" style={{ color: C.paperDim }}>
            {inquiry.email}{inquiry.phone ? ` · ${inquiry.phone}` : ""} · {new Date(inquiry.created_at).toLocaleString()}
            {!inquiry.sender_id && " · public inquiry"}
          </p>
        </div>
        <select
          value={status}
          onChange={(e) => setStatus(e.target.value as InquiryStatus)}
          className="text-xs px-3 py-1.5 rounded-full"
          style={{ background: "#FFFFFF", color: C.gold, border: `1px solid ${C.hairline}` }}
        >
          {STATUSES.map((s) => (
            <option key={s} value={s}>{s.replace("_", " ")}</option>
          ))}
        </select>
      </div>

      <p className="text-sm mb-3" style={{ color: C.paper }}>{inquiry.message}</p>

      <textarea
        value={reply}
        onChange={(e) => setReply(e.target.value)}
        placeholder="Write a reply the sender will see…"
        rows={2}
        className="w-full px-3 py-2 rounded-lg text-sm mb-2"
        style={{ background: "#FFFFFF", color: C.paper, border: `1px solid ${C.hairline}` }}
      />
      <div className="flex items-center gap-3">
        <button
          disabled={isPending}
          onClick={save}
          className="text-xs font-semibold px-3 py-1.5 rounded-full disabled:opacity-50"
          style={{ background: C.gold, color: "#0B2942" }}
        >
          {isPending ? "Saving…" : "Save reply & status"}
        </button>
        {saved && <span className="text-xs" style={{ color: C.ok }}>Saved</span>}
      </div>
    </div>
  );
}
