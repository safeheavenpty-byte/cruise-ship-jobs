import { createClient } from "@/lib/supabase/server";
import InquiryRow from "./InquiryRow";
import type { Inquiry } from "@/types/database";

const C = { gold: "#A97C50", paper: "#0B2942", paperDim: "#5B7286" };

export default async function StaffInquiriesPage() {
  const supabase = await createClient();
  const { data: inquiries } = await supabase
    .from("inquiries")
    .select("*")
    .order("created_at", { ascending: false });

  return (
    <div>
      <p className="text-xs mb-1" style={{ color: C.gold, fontFamily: "monospace" }}>INQUIRIES</p>
      <h1 className="text-3xl mb-2" style={{ color: C.paper, fontFamily: "serif" }}>Consult requests</h1>
      <p className="text-xs mb-8" style={{ color: C.paperDim }}>
        From applicants, partners, and public visitors using the /contact page instead of WhatsApp.
      </p>

      {!inquiries || inquiries.length === 0 ? (
        <p className="text-sm" style={{ color: C.paperDim }}>No inquiries yet.</p>
      ) : (
        <div className="space-y-3">
          {(inquiries as Inquiry[]).map((i) => (
            <InquiryRow key={i.id} inquiry={i} />
          ))}
        </div>
      )}
    </div>
  );
}
