import { createClient } from "@/lib/supabase/server";

const C = { surface: "#FFFFFF", wood: "#A97C50", navy: "#0B2942", navyDim: "#5B7286", border: "#E3DCC9", ok: "#4F8B6E", warn: "#B5651D" };

function YesNoBadge({ value }: { value: boolean | null }) {
  if (value === null) return <span style={{ color: C.navyDim }}>—</span>;
  return (
    <span className="text-xs font-semibold px-2.5 py-1 rounded-full" style={{ background: value ? C.ok : "#F7F4EC", color: value ? "#FFFFFF" : C.navyDim, border: value ? "none" : `1px solid ${C.border}` }}>
      {value ? "Yes" : "No"}
    </span>
  );
}

export default async function StaffScreeningPage() {
  const supabase = await createClient();
  const { data: rows } = await supabase
    .from("screening_answers")
    .select("*, profiles:applicant_id (full_name)")
    .order("submitted_at", { ascending: false });

  return (
    <div>
      <p className="text-xs mb-1" style={{ color: C.wood, fontFamily: "monospace" }}>SCREENING ANSWERS</p>
      <h1 className="text-3xl mb-8" style={{ color: C.navy, fontFamily: "serif" }}>Applicant screening</h1>

      {!rows || rows.length === 0 ? (
        <p className="text-sm" style={{ color: C.navyDim }}>No screening answers submitted yet.</p>
      ) : (
        <div className="space-y-4">
          {rows.map((r: any) => (
            <div key={r.id} className="rounded-xl p-5" style={{ background: C.surface, border: `1px solid ${C.border}` }}>
              <p className="text-sm mb-3" style={{ color: C.navy }}>{r.profiles?.full_name ?? "Unknown applicant"}</p>

              <div className="grid grid-cols-2 gap-3 mb-4">
                <div className="flex items-center justify-between text-xs" style={{ color: C.navyDim }}>
                  US C1/D issued before <YesNoBadge value={r.us_c1d_issued_before} />
                </div>
                <div className="flex items-center justify-between text-xs" style={{ color: C.navyDim }}>
                  US C1/D currently valid <YesNoBadge value={r.us_c1d_currently_valid} />
                </div>
                <div className="flex items-center justify-between text-xs" style={{ color: C.navyDim }}>
                  Onboard experience <YesNoBadge value={r.has_onboard_experience} />
                </div>
                <div className="flex items-center justify-between text-xs" style={{ color: C.navyDim }}>
                  Can work long hours <YesNoBadge value={r.can_work_long_hours} />
                </div>
              </div>

              <div className="space-y-3 pt-3" style={{ borderTop: `1px solid ${C.border}` }}>
                <div>
                  <p className="text-xs mb-1" style={{ color: C.wood }}>Uncomfortable clients:</p>
                  <p className="text-sm" style={{ color: C.navy }}>{r.uncomfortable_clients_answer}</p>
                </div>
                <div>
                  <p className="text-xs mb-1" style={{ color: C.wood }}>Drinks during working hours:</p>
                  <p className="text-sm" style={{ color: C.navy }}>{r.drinks_invite_answer}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
