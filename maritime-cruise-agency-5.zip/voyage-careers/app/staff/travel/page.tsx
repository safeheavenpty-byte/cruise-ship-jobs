import { createClient } from "@/lib/supabase/server";
import TravelRow from "./TravelRow";

const C = { gold: "#A97C50", paper: "#0B2942", paperDim: "#5B7286" };

export default async function StaffTravelPage() {
  const supabase = await createClient();

  const [{ data: requests }, { data: accommodations }] = await Promise.all([
    supabase
      .from("travel_requests")
      .select("*, profiles:applicant_id (full_name)")
      .order("created_at", { ascending: true }),
    supabase.from("accommodations").select("id, title, location, is_available").eq("is_available", true),
  ]);

  // For accommodation-type requests, work out per-applicant whether all
  // of their documents are approved yet — this drives the "pending while
  // documents are under review" note shown next to each request.
  const applicantIds = Array.from(new Set((requests ?? []).map((r: any) => r.applicant_id)));
  const documentsClearedByApplicant: Record<string, boolean> = {};
  if (applicantIds.length > 0) {
    const { data: docs } = await supabase
      .from("documents")
      .select("applicant_id, status")
      .in("applicant_id", applicantIds);
    applicantIds.forEach((id) => {
      const theirDocs = (docs ?? []).filter((d) => d.applicant_id === id);
      documentsClearedByApplicant[id] = theirDocs.length > 0 && theirDocs.every((d) => d.status === "approved");
    });
  }

  return (
    <div>
      <p className="text-xs mb-1" style={{ color: C.gold, fontFamily: "monospace" }}>VISA & TRAVEL</p>
      <h1 className="text-3xl mb-6" style={{ color: C.paper, fontFamily: "serif" }}>Travel requests</h1>

      {!requests || requests.length === 0 ? (
        <p className="text-sm" style={{ color: C.paperDim }}>No travel requests yet.</p>
      ) : (
        <div className="space-y-3">
          {requests.map((r: any) => (
            <TravelRow
              key={r.id}
              id={r.id}
              applicantName={r.profiles?.full_name ?? "Unknown applicant"}
              type={r.type}
              provider={r.provider}
              status={r.status}
              accommodationId={r.accommodation_id}
              documentsCleared={documentsClearedByApplicant[r.applicant_id] ?? false}
              accommodations={accommodations ?? []}
            />
          ))}
        </div>
      )}
    </div>
  );
}
