"use client";

import { useTransition } from "react";
import { updateTravelStatus, assignAccommodation } from "@/lib/actions/staff";
import type { TravelStatus } from "@/types/database";

const C = { gold: "#A97C50", paper: "#0B2942", paperDim: "#5B7286", hairline: "#E3DCC9", warn: "#B5651D" };

const STATUSES: TravelStatus[] = ["requested", "pending", "in_progress", "confirmed", "declined"];

export default function TravelRow({
  id,
  applicantName,
  type,
  provider,
  status,
  accommodationId,
  documentsCleared,
  accommodations,
}: {
  id: string;
  applicantName: string;
  type: string;
  provider: string;
  status: TravelStatus;
  accommodationId: string | null;
  documentsCleared: boolean;
  accommodations: { id: string; title: string; location: string | null }[];
}) {
  const [isPending, startTransition] = useTransition();

  return (
    <div
      className="rounded-xl p-4 flex items-center justify-between gap-4 flex-wrap"
      style={{ background: "#FBF8F1", border: `1px solid ${C.hairline}` }}
    >
      <div>
        <p className="text-sm capitalize" style={{ color: C.paper }}>{type}</p>
        <p className="text-xs mt-0.5" style={{ color: C.paperDim }}>
          {applicantName} · {provider === "manual" ? "manual tracking" : "API-linked"}
        </p>
        {type === "accommodation" && !documentsCleared && (
          <p className="text-xs mt-1" style={{ color: C.warn }}>
            Documents still under review — can't confirm until cleared
          </p>
        )}
      </div>

      <div className="flex items-center gap-2 flex-wrap">
        {type === "accommodation" && (
          <select
            disabled={isPending}
            defaultValue={accommodationId ?? ""}
            onChange={(e) =>
              startTransition(() => assignAccommodation(id, e.target.value || null))
            }
            className="text-xs px-3 py-2 rounded-full"
            style={{ background: "#FFFFFF", color: C.gold, border: `1px solid ${C.hairline}` }}
          >
            <option value="">No listing assigned</option>
            {accommodations.map((a) => (
              <option key={a.id} value={a.id}>
                {a.title}{a.location ? ` — ${a.location}` : ""}
              </option>
            ))}
          </select>
        )}
        <select
          disabled={isPending}
          defaultValue={status}
          onChange={(e) => startTransition(() => updateTravelStatus(id, e.target.value as TravelStatus))}
          className="text-xs px-3 py-2 rounded-full"
          style={{ background: "#FFFFFF", color: C.gold, border: `1px solid ${C.hairline}` }}
        >
          {STATUSES.map((s) => (
            <option key={s} value={s}>{s.replace("_", " ")}</option>
          ))}
        </select>
      </div>
    </div>
  );
}
