import { createClient } from "@/lib/supabase/server";
import DocumentRow from "./DocumentRow";

const C = { gold: "#A97C50", paper: "#0B2942", paperDim: "#5B7286" };

export default async function StaffDocumentsPage() {
  const supabase = await createClient();

  // Join documents with the applicant's profile for display name.
  const { data: documents } = await supabase
    .from("documents")
    .select("*, profiles:applicant_id (full_name)")
    .in("status", ["submitted", "under_review"])
    .order("submitted_at", { ascending: true });

  return (
    <div>
      <p className="text-xs mb-1" style={{ color: C.gold, fontFamily: "monospace" }}>DOCUMENT WALLET REVIEW</p>
      <h1 className="text-3xl mb-6" style={{ color: C.paper, fontFamily: "serif" }}>Pending documents</h1>

      {!documents || documents.length === 0 ? (
        <p className="text-sm" style={{ color: C.paperDim }}>Nothing waiting on you right now.</p>
      ) : (
        <div className="space-y-3">
          {documents.map((doc: any) => (
            <DocumentRow key={doc.id} doc={doc} applicantName={doc.profiles?.full_name ?? "Unknown applicant"} />
          ))}
        </div>
      )}
    </div>
  );
}
