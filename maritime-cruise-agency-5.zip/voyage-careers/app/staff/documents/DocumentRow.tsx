"use client";

import { useTransition } from "react";
import { updateDocumentStatus } from "@/lib/actions/staff";
import type { DocumentRow as DocRow } from "@/types/database";

const C = { gold: "#A97C50", paper: "#0B2942", paperDim: "#5B7286", ok: "#4F8B6E", warn: "#B5651D", hairline: "#E3DCC9" };

const LABELS: Record<string, string> = {
  cv: "CV / Résumé",
  police_clearance: "Police Clearance",
  medical_exam: "Medical Exam Records",
  certificate: "Certificate",
  language_accreditation: "Language Accreditation",
};

export default function DocumentRow({ doc, applicantName }: { doc: DocRow; applicantName: string }) {
  const [isPending, startTransition] = useTransition();

  function act(status: "approved" | "rejected") {
    startTransition(() => updateDocumentStatus(doc.id, status));
  }

  return (
    <div
      className="rounded-xl p-4 flex items-center justify-between gap-4 flex-wrap"
      style={{ background: "#FBF8F1", border: `1px solid ${C.hairline}` }}
    >
      <div>
        <p className="text-sm" style={{ color: C.paper }}>
          {LABELS[doc.type] ?? doc.type}{doc.test_type ? ` · ${doc.test_type}` : ""}
        </p>
        <p className="text-xs mt-0.5" style={{ color: C.paperDim }}>{applicantName}</p>
      </div>
      <div className="flex items-center gap-2">
        <a
          href={`/api/documents/${doc.id}/file`}
          target="_blank"
          rel="noreferrer"
          className="text-xs underline"
          style={{ color: C.gold }}
        >
          View file
        </a>
        <button
          disabled={isPending}
          onClick={() => act("approved")}
          className="text-xs font-semibold px-3 py-1.5 rounded-full disabled:opacity-50"
          style={{ background: C.ok, color: "#0B2942" }}
        >
          Approve
        </button>
        <button
          disabled={isPending}
          onClick={() => act("rejected")}
          className="text-xs font-semibold px-3 py-1.5 rounded-full disabled:opacity-50"
          style={{ background: C.warn, color: "#0B2942" }}
        >
          Reject
        </button>
      </div>
    </div>
  );
}
