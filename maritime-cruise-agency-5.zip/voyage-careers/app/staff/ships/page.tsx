"use client";

import { useEffect, useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { createShip, toggleShipActive } from "@/lib/actions/staff";
import type { Ship } from "@/types/database";

const C = { surface: "#FFFFFF", wood: "#A97C50", navy: "#0B2942", navyDim: "#5B7286", border: "#E3DCC9", ok: "#4F8B6E" };

export default function StaffShipsPage() {
  const supabase = createClient();
  const [ships, setShips] = useState<Ship[]>([]);
  const [loading, setLoading] = useState(true);
  const [formOpen, setFormOpen] = useState(false);
  const [name, setName] = useState("");
  const [cruiseLine, setCruiseLine] = useState("");
  const [notes, setNotes] = useState("");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function load() {
    const { data } = await supabase.from("ships").select("*").order("created_at", { ascending: false });
    setShips((data ?? []) as Ship[]);
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setSaving(true);
    try {
      await createShip({ name, cruise_line: cruiseLine, notes });
      setName(""); setCruiseLine(""); setNotes("");
      setFormOpen(false);
      await load();
    } catch (e: any) {
      setError(e.message);
    } finally {
      setSaving(false);
    }
  }

  function toggle(ship: Ship) {
    toggleShipActive(ship.id, !ship.is_active).then(load);
  }

  return (
    <div>
      <p className="text-xs mb-1" style={{ color: C.wood, fontFamily: "monospace" }}>SHIPS UNDER MANAGEMENT</p>
      <h1 className="text-3xl mb-6" style={{ color: C.navy, fontFamily: "serif" }}>Manage your fleet</h1>

      {!formOpen ? (
        <button
          onClick={() => setFormOpen(true)}
          className="text-xs font-semibold px-4 py-2 rounded-full mb-6"
          style={{ background: C.wood, color: "#FFFFFF" }}
        >
          + Add a ship
        </button>
      ) : (
        <form onSubmit={submit} className="rounded-xl p-5 mb-6 space-y-3" style={{ background: "#FBF8F1", border: `1px solid ${C.border}` }}>
          {error && <p className="text-xs" style={{ color: "#B5651D" }}>{error}</p>}
          <input
            placeholder="Ship name (e.g. Ocean Explorer)"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
            className="w-full px-3 py-2 rounded-lg text-sm"
            style={{ background: "#F7F4EC", color: C.navy, border: `1px solid ${C.border}` }}
          />
          <input
            placeholder="Cruise line"
            value={cruiseLine}
            onChange={(e) => setCruiseLine(e.target.value)}
            className="w-full px-3 py-2 rounded-lg text-sm"
            style={{ background: "#F7F4EC", color: C.navy, border: `1px solid ${C.border}` }}
          />
          <textarea
            placeholder="Notes (route, capacity, etc.)"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            rows={3}
            className="w-full px-3 py-2 rounded-lg text-sm"
            style={{ background: "#F7F4EC", color: C.navy, border: `1px solid ${C.border}` }}
          />
          <div className="flex gap-2">
            <button
              type="submit"
              disabled={saving}
              className="text-xs font-semibold px-4 py-2 rounded-full disabled:opacity-50"
              style={{ background: C.wood, color: "#FFFFFF" }}
            >
              {saving ? "Adding…" : "Add ship"}
            </button>
            <button type="button" onClick={() => setFormOpen(false)} className="text-xs px-4 py-2" style={{ color: C.navyDim }}>
              Cancel
            </button>
          </div>
        </form>
      )}

      {loading ? (
        <p className="text-sm" style={{ color: C.navyDim }}>Loading…</p>
      ) : ships.length === 0 ? (
        <p className="text-sm" style={{ color: C.navyDim }}>No ships added yet.</p>
      ) : (
        <div className="space-y-3">
          {ships.map((ship) => (
            <div key={ship.id} className="rounded-xl p-4 flex items-center justify-between gap-4 flex-wrap" style={{ background: C.surface, border: `1px solid ${C.border}` }}>
              <div>
                <p className="text-sm" style={{ color: C.navy }}>{ship.name}</p>
                <p className="text-xs mt-0.5" style={{ color: C.navyDim }}>{ship.cruise_line}</p>
                {ship.notes && <p className="text-xs mt-1" style={{ color: C.navyDim }}>{ship.notes}</p>}
              </div>
              <button
                onClick={() => toggle(ship)}
                className="text-xs font-semibold px-3 py-1.5 rounded-full shrink-0"
                style={{ background: ship.is_active ? C.ok : "#F7F4EC", color: ship.is_active ? "#FFFFFF" : C.navyDim, border: ship.is_active ? "none" : `1px solid ${C.border}` }}
              >
                {ship.is_active ? "Active" : "Inactive"}
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
