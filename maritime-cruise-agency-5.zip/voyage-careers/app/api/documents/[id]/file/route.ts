import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

// Staff (or the owning applicant) hit this to view an uploaded document.
// RLS on `documents` and the storage bucket enforce who can reach the file;
// this route just turns a DB row into a short-lived signed URL.
export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const supabase = await createClient();

  const { data: doc, error } = await supabase
    .from("documents")
    .select("file_path")
    .eq("id", id)
    .single();

  if (error || !doc) {
    return NextResponse.json({ error: "Document not found" }, { status: 404 });
  }

  const { data: signed, error: signError } = await supabase.storage
    .from("documents")
    .createSignedUrl(doc.file_path, 60); // 60-second link

  if (signError || !signed) {
    return NextResponse.json({ error: "Could not generate file link" }, { status: 500 });
  }

  return NextResponse.redirect(signed.signedUrl);
}
