import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import type { JobCategory } from "@/types/database";

// Anyone signed in can reach this (RLS on exam_documents allows any
// authenticated read); it resolves to the most recently uploaded PDF
// for that category and redirects to a short-lived signed URL.
export async function GET(_req: Request, { params }: { params: Promise<{ category: string }> }) {
  const { category } = await params;
  const supabase = await createClient();

  const { data: doc, error } = await supabase
    .from("exam_documents")
    .select("file_path")
    .eq("category", category as JobCategory)
    .order("created_at", { ascending: false })
    .limit(1)
    .single();

  if (error || !doc) {
    return NextResponse.json({ error: "No exam document found for this category" }, { status: 404 });
  }

  const { data: signed, error: signError } = await supabase.storage
    .from("exam-documents")
    .createSignedUrl(doc.file_path, 120);

  if (signError || !signed) {
    return NextResponse.json({ error: "Could not generate file link" }, { status: 500 });
  }

  return NextResponse.redirect(signed.signedUrl);
}
