"use client";

import { useState } from "react";
import Link from "next/link";
import { createClient } from "@/lib/supabase/client";
import ScamNotice from "@/components/ScamNotice";

const C = { ink: "#F7F4EC", surface: "#FFFFFF", gold: "#A97C50", paper: "#0B2942", paperDim: "#5B7286", hairline: "#E3DCC9", ok: "#4F8B6E" };

export default function ContactPage() {
  const supabase = createClient();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [message, setMessage] = useState("");
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setSending(true);

    // Direct client-side insert — works for anonymous visitors too,
    // since RLS just requires sender_id to be null when not signed in.
    const {
      data: { user },
    } = await supabase.auth.getUser();

    const { error } = await supabase.from("inquiries").insert({
      sender_id: user?.id ?? null,
      name,
      email,
      phone: phone || null,
      message,
      status: "new",
    });

    if (error) setError(error.message);
    else setSent(true);
    setSending(false);
  }

  return (
    <div className="min-h-screen flex items-center justify-center px-4 py-10" style={{ background: C.ink }}>
      <div className="w-full max-w-lg">
        <div className="mb-6">
          <Link href="/" className="text-xs" style={{ color: C.paperDim }}>← Maritime Cruise Agency</Link>
          <h1 className="text-2xl mt-2" style={{ color: C.paper, fontFamily: "serif" }}>Talk to us</h1>
          <p className="text-xs mt-1" style={{ color: C.paperDim }}>
            For applicants, employer partners, or anyone who wants to verify a job offer before proceeding.
          </p>
        </div>

        <div className="mb-6"><ScamNotice /></div>

        {sent ? (
          <div className="rounded-xl p-6 text-center" style={{ background: C.surface, border: `1px solid ${C.hairline}` }}>
            <p className="text-lg mb-1" style={{ color: C.ok, fontFamily: "serif" }}>Message received</p>
            <p className="text-xs" style={{ color: C.paperDim }}>
              Our team will follow up by email — never by WhatsApp. If you have an account, you can also see this
              thread under Messages once you sign in.
            </p>
          </div>
        ) : (
          <form onSubmit={submit} className="rounded-xl p-6 space-y-3" style={{ background: C.surface, border: `1px solid ${C.hairline}` }}>
            {error && <p className="text-xs" style={{ color: "#B5651D" }}>{error}</p>}
            <input
              placeholder="Your name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
              className="w-full px-3 py-2 rounded-lg text-sm"
              style={{ background: C.ink, color: C.paper, border: `1px solid ${C.hairline}` }}
            />
            <input
              type="email"
              placeholder="Email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              className="w-full px-3 py-2 rounded-lg text-sm"
              style={{ background: C.ink, color: C.paper, border: `1px solid ${C.hairline}` }}
            />
            <input
              placeholder="Phone (optional)"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              className="w-full px-3 py-2 rounded-lg text-sm"
              style={{ background: C.ink, color: C.paper, border: `1px solid ${C.hairline}` }}
            />
            <textarea
              placeholder="How can we help? Include any job offer details you'd like us to verify."
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              required
              rows={5}
              className="w-full px-3 py-2 rounded-lg text-sm"
              style={{ background: C.ink, color: C.paper, border: `1px solid ${C.hairline}` }}
            />
            <button
              type="submit"
              disabled={sending}
              className="w-full py-2.5 rounded-full text-sm font-semibold disabled:opacity-50"
              style={{ background: C.gold, color: "#0B2942" }}
            >
              {sending ? "Sending…" : "Send message"}
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
