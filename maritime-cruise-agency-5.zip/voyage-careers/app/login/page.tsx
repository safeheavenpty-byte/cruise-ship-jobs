"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { createClient } from "@/lib/supabase/client";
import { sendWelcomeEmail } from "@/lib/actions/applicant";
import ScamNotice from "@/components/ScamNotice";

const C = {
  bg: "#F7F4EC",
  surface: "#FFFFFF",
  wood: "#A97C50",
  navy: "#0B2942",
  navyDim: "#5B7286",
  border: "#E3DCC9",
  warn: "#B5651D",
};

const COUNTRIES = [
  "South Africa", "Philippines", "India", "Kenya", "Nigeria", "Zimbabwe",
  "Ghana", "United Kingdom", "United States", "Canada", "Australia", "Other",
];
const COUNTRY_CODES = [
  { code: "+27", label: "+27 (South Africa)" },
  { code: "+63", label: "+63 (Philippines)" },
  { code: "+91", label: "+91 (India)" },
  { code: "+254", label: "+254 (Kenya)" },
  { code: "+234", label: "+234 (Nigeria)" },
  { code: "+263", label: "+263 (Zimbabwe)" },
  { code: "+233", label: "+233 (Ghana)" },
  { code: "+44", label: "+44 (UK)" },
  { code: "+1", label: "+1 (US/Canada)" },
  { code: "+61", label: "+61 (Australia)" },
];
const REFERRAL_SOURCES = [
  "Facebook", "Instagram", "TikTok", "Google search", "Friend or family",
  "Recruitment agent", "Job fair", "Other",
];

const inputStyle = {
  background: C.bg,
  color: C.navy,
  border: `1px solid ${C.border}`,
};

export default function LoginPage() {
  const router = useRouter();
  const supabase = createClient();
  const [mode, setMode] = useState<"signin" | "signup">("signin");

  // signin fields
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  // signup fields
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [countryOfResidence, setCountryOfResidence] = useState("");
  const [nationality, setNationality] = useState("");
  const [phoneCountryCode, setPhoneCountryCode] = useState("+27");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [dateOfBirth, setDateOfBirth] = useState("");
  const [gender, setGender] = useState("");
  const [referralSource, setReferralSource] = useState("");

  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);

    if (mode === "signup") {
      const { error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            first_name: firstName,
            last_name: lastName,
            country_of_residence: countryOfResidence,
            nationality,
            phone_country_code: phoneCountryCode,
            phone_number: phoneNumber,
            date_of_birth: dateOfBirth,
            gender,
            referral_source: referralSource,
          },
        },
      });
      if (error) setError(error.message);
      else {
        await sendWelcomeEmail(firstName, email);
        router.push("/app/welcome");
      }
    } else {
      const { error, data } = await supabase.auth.signInWithPassword({ email, password });
      if (error) {
        setError(error.message);
      } else {
        const { data: profile } = await supabase
          .from("profiles")
          .select("role")
          .eq("id", data.user.id)
          .single();
        if (profile?.role === "staff") router.push("/staff");
        else if (profile?.role === "partner") router.push("/partner");
        else router.push("/app");
      }
    }
    setLoading(false);
  }

  return (
    <div className="min-h-screen flex items-center justify-center px-4 py-10" style={{ background: C.bg }}>
      <div className="w-full max-w-md">
        <div className="text-center mb-6">
          <Link href="/" className="text-lg" style={{ color: C.navy, fontFamily: "serif" }}>
            Maritime Cruise Agency
          </Link>
        </div>

        <form
          onSubmit={handleSubmit}
          className="rounded-xl p-8"
          style={{ background: C.surface, border: `1px solid ${C.border}`, boxShadow: "0 4px 20px rgba(11,41,66,0.06)" }}
        >
          <h1 className="text-xl mb-1" style={{ color: C.navy, fontFamily: "serif" }}>
            {mode === "signin" ? "Welcome back" : "Create your account"}
          </h1>
          <p className="text-xs mb-6" style={{ color: C.navyDim }}>
            {mode === "signin" ? "Sign in to continue your application" : "Register as an applicant"}
          </p>

          {mode === "signup" && (
            <div className="space-y-3 mb-3">
              <div className="grid grid-cols-2 gap-3">
                <input
                  placeholder="First name"
                  value={firstName}
                  onChange={(e) => setFirstName(e.target.value)}
                  required
                  className="px-3 py-2 rounded-lg text-sm outline-none"
                  style={inputStyle}
                />
                <input
                  placeholder="Last name"
                  value={lastName}
                  onChange={(e) => setLastName(e.target.value)}
                  required
                  className="px-3 py-2 rounded-lg text-sm outline-none"
                  style={inputStyle}
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <select
                  value={countryOfResidence}
                  onChange={(e) => setCountryOfResidence(e.target.value)}
                  required
                  className="px-3 py-2 rounded-lg text-sm outline-none"
                  style={inputStyle}
                >
                  <option value="" disabled>Country of residence</option>
                  {COUNTRIES.map((c) => <option key={c} value={c}>{c}</option>)}
                </select>
                <select
                  value={nationality}
                  onChange={(e) => setNationality(e.target.value)}
                  required
                  className="px-3 py-2 rounded-lg text-sm outline-none"
                  style={inputStyle}
                >
                  <option value="" disabled>Nationality</option>
                  {COUNTRIES.map((c) => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>

              <div className="grid grid-cols-[auto_1fr] gap-3">
                <select
                  value={phoneCountryCode}
                  onChange={(e) => setPhoneCountryCode(e.target.value)}
                  className="px-2 py-2 rounded-lg text-sm outline-none"
                  style={inputStyle}
                >
                  {COUNTRY_CODES.map((c) => <option key={c.code} value={c.code}>{c.label}</option>)}
                </select>
                <input
                  type="tel"
                  placeholder="Phone number"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  required
                  className="px-3 py-2 rounded-lg text-sm outline-none w-full"
                  style={inputStyle}
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <label className="flex flex-col gap-1">
                  <span className="text-[11px]" style={{ color: C.navyDim }}>Date of birth</span>
                  <input
                    type="date"
                    value={dateOfBirth}
                    onChange={(e) => setDateOfBirth(e.target.value)}
                    required
                    className="px-3 py-2 rounded-lg text-sm outline-none"
                    style={inputStyle}
                  />
                </label>
                <label className="flex flex-col gap-1">
                  <span className="text-[11px]" style={{ color: C.navyDim }}>Gender</span>
                  <select
                    value={gender}
                    onChange={(e) => setGender(e.target.value)}
                    required
                    className="px-3 py-2 rounded-lg text-sm outline-none"
                    style={inputStyle}
                  >
                    <option value="" disabled>Select</option>
                    <option value="female">Female</option>
                    <option value="male">Male</option>
                    <option value="other">Other</option>
                    <option value="prefer_not_to_say">Prefer not to say</option>
                  </select>
                </label>
              </div>

              <select
                value={referralSource}
                onChange={(e) => setReferralSource(e.target.value)}
                required
                className="w-full px-3 py-2 rounded-lg text-sm outline-none"
                style={inputStyle}
              >
                <option value="" disabled>How did you hear about us?</option>
                {REFERRAL_SOURCES.map((s) => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
          )}

          <input
            type="email"
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
            className="w-full mb-3 px-3 py-2 rounded-lg text-sm outline-none"
            style={inputStyle}
          />
          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            minLength={6}
            className="w-full mb-4 px-3 py-2 rounded-lg text-sm outline-none"
            style={inputStyle}
          />

          {error && <p className="text-xs mb-3" style={{ color: C.warn }}>{error}</p>}

          <button
            type="submit"
            disabled={loading}
            className="w-full py-2.5 rounded-full text-sm font-semibold disabled:opacity-50"
            style={{ background: C.wood, color: "#FFFFFF" }}
          >
            {loading ? "Please wait…" : mode === "signin" ? "Sign in" : "Create account"}
          </button>

          <button
            type="button"
            onClick={() => setMode(mode === "signin" ? "signup" : "signin")}
            className="w-full text-xs mt-4 underline"
            style={{ color: C.wood }}
          >
            {mode === "signin" ? "Need an account? Sign up" : "Already have an account? Sign in"}
          </button>

          <p className="text-[10px] mt-6" style={{ color: "#8A9BAA" }}>
            Note: staff and partner accounts are created by an admin and promoted
            via the <code>profiles.role</code> column — they don't sign up here.
          </p>
        </form>

        <div className="mt-4"><ScamNotice compact /></div>
        <p className="text-xs text-center mt-4" style={{ color: C.navyDim }}>
          Not sure if a message is really from us?{" "}
          <Link href="/contact" className="underline" style={{ color: C.wood }}>Verify it here</Link>
        </p>
      </div>
    </div>
  );
}
