import Link from "next/link";
import { Ship, Stethoscope, ConciergeBell, ShieldCheck, FileCheck, Compass } from "lucide-react";
import HeroSlideshow from "@/components/HeroSlideshow";

const C = {
  bg: "#F7F4EC",
  surface: "#FFFFFF",
  navy: "#0B2942",
  navySoft: "#123A5E",
  navyDim: "#5B7286",
  wood: "#A97C50",
  woodDark: "#8B5E34",
  border: "#E3DCC9",
};

const CATEGORIES = [
  { icon: Ship, title: "Cruise Ship", desc: "Deck, hospitality, and entertainment roles aboard leading cruise lines." },
  { icon: ConciergeBell, title: "Hospitality", desc: "Hotels, resorts, and guest service positions worldwide." },
  { icon: Stethoscope, title: "Healthcare", desc: "Nursing and caregiving roles with vetted overseas employers." },
];

const STEPS = [
  { title: "Apply", desc: "Create an account and apply to open roles that match your experience." },
  { title: "Assess", desc: "Complete the qualifying exam and submit your CV, clearance, and certificates." },
  { title: "Confirm", desc: "We review your documents, then help arrange your visa, flights, and accommodation." },
];

export default function LandingPage() {
  return (
    <div style={{ background: C.bg }}>
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-30">
        <div className="max-w-6xl mx-auto flex items-center justify-between px-6 py-5">
          <span className="text-lg" style={{ color: "#FFFFFF", fontFamily: "serif" }}>Maritime Cruise Agency</span>
          <nav className="flex items-center gap-6">
            <Link href="/contact" className="text-sm hidden sm:inline" style={{ color: "#FFFFFF" }}>Contact</Link>
            <Link
              href="/login"
              className="text-sm font-semibold px-4 py-2 rounded-full"
              style={{ background: C.wood, color: "#FFFFFF" }}
            >
              Sign in
            </Link>
          </nav>
        </div>
      </header>

      {/* Hero */}
      <section className="relative h-[90vh] min-h-[560px] flex items-end">
        <HeroSlideshow />
        <div className="relative z-10 max-w-6xl mx-auto px-6 pb-20 w-full">
          <p className="text-xs tracking-widest uppercase mb-3" style={{ color: C.wood, fontFamily: "monospace" }}>
            Cruise · Hospitality · Healthcare
          </p>
          <h1 className="text-4xl md:text-6xl mb-4 max-w-2xl" style={{ color: "#FFFFFF", fontFamily: "serif", lineHeight: 1.1 }}>
            Your career at sea and beyond starts here.
          </h1>
          <p className="text-sm md:text-base max-w-lg mb-8" style={{ color: "#E9E4D8" }}>
            Maritime Cruise Agency places qualified candidates into cruise ship, hospitality, and
            healthcare roles worldwide — with every step of your application tracked in one place.
          </p>
          <div className="flex flex-wrap gap-3">
            <Link
              href="/login"
              className="text-sm font-semibold px-6 py-3 rounded-full"
              style={{ background: C.wood, color: "#FFFFFF" }}
            >
              Start your application
            </Link>
            <Link
              href="/contact"
              className="text-sm font-semibold px-6 py-3 rounded-full"
              style={{ border: "1px solid rgba(255,255,255,0.5)", color: "#FFFFFF" }}
            >
              Talk to our team
            </Link>
          </div>
        </div>
      </section>

      {/* Job categories */}
      <section className="max-w-6xl mx-auto px-6 py-20">
        <p className="text-xs tracking-widest uppercase mb-2" style={{ color: C.wood, fontFamily: "monospace" }}>
          Where you could work
        </p>
        <h2 className="text-3xl mb-10" style={{ color: C.navy, fontFamily: "serif" }}>Three industries, one platform</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {CATEGORIES.map(({ icon: Icon, title, desc }) => (
            <div key={title} className="rounded-xl p-6" style={{ background: C.surface, border: `1px solid ${C.border}` }}>
              <div
                className="w-11 h-11 rounded-full flex items-center justify-center mb-4"
                style={{ background: C.bg, border: `1px solid ${C.border}` }}
              >
                <Icon size={20} style={{ color: C.wood }} />
              </div>
              <h3 className="text-lg mb-1" style={{ color: C.navy, fontFamily: "serif" }}>{title}</h3>
              <p className="text-sm" style={{ color: C.navyDim }}>{desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* How it works */}
      <section style={{ background: C.navy }} className="py-20">
        <div className="max-w-6xl mx-auto px-6">
          <p className="text-xs tracking-widest uppercase mb-2" style={{ color: C.wood, fontFamily: "monospace" }}>
            How it works
          </p>
          <h2 className="text-3xl mb-10" style={{ color: "#FFFFFF", fontFamily: "serif" }}>From application to boarding</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {STEPS.map((step, i) => (
              <div key={step.title}>
                <div
                  className="w-9 h-9 rounded-full flex items-center justify-center text-sm mb-4"
                  style={{ border: `1.5px solid ${C.wood}`, color: C.wood, fontFamily: "monospace" }}
                >
                  {i + 1}
                </div>
                <h3 className="text-lg mb-2" style={{ color: "#FFFFFF", fontFamily: "serif" }}>{step.title}</h3>
                <p className="text-sm" style={{ color: "#B7C4D1" }}>{step.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Trust / safety */}
      <section className="max-w-6xl mx-auto px-6 py-20">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="rounded-xl p-6 flex gap-4" style={{ background: C.surface, border: `1px solid ${C.border}` }}>
            <ShieldCheck size={24} style={{ color: C.wood, flexShrink: 0 }} />
            <div>
              <h3 className="text-base mb-1" style={{ color: C.navy, fontFamily: "serif" }}>We never use WhatsApp</h3>
              <p className="text-sm" style={{ color: C.navyDim }}>
                Every official communication happens through this platform or verified email. If
                you're contacted on WhatsApp claiming to be us, it's a scam — verify it on our contact page.
              </p>
            </div>
          </div>
          <div className="rounded-xl p-6 flex gap-4" style={{ background: C.surface, border: `1px solid ${C.border}` }}>
            <FileCheck size={24} style={{ color: C.wood, flexShrink: 0 }} />
            <div>
              <h3 className="text-base mb-1" style={{ color: C.navy, fontFamily: "serif" }}>Track everything in one place</h3>
              <p className="text-sm" style={{ color: C.navyDim }}>
                Applications, exams, documents, visas, accommodation, and flights — all tracked with
                clear status updates, no guessing.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="max-w-6xl mx-auto px-6 pb-20">
        <div
          className="rounded-2xl p-10 md:p-14 text-center"
          style={{ background: `linear-gradient(135deg, ${C.navy}, ${C.navySoft})` }}
        >
          <h2 className="text-2xl md:text-3xl mb-3" style={{ color: "#FFFFFF", fontFamily: "serif" }}>
            Ready to start your journey?
          </h2>
          <p className="text-sm mb-6" style={{ color: "#B7C4D1" }}>
            Create your account and browse open roles today.
          </p>
          <Link
            href="/login"
            className="inline-block text-sm font-semibold px-6 py-3 rounded-full"
            style={{ background: C.wood, color: "#FFFFFF" }}
          >
            <span className="inline-flex items-center gap-2"><Compass size={16} /> Get started</span>
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t" style={{ borderColor: C.border }}>
        <div className="max-w-6xl mx-auto px-6 py-8 flex flex-col sm:flex-row justify-between items-center gap-3">
          <span className="text-xs" style={{ color: C.navyDim }}>© {new Date().getFullYear()} Maritime Cruise Agency</span>
          <Link href="/contact" className="text-xs underline" style={{ color: C.wood }}>Contact us</Link>
        </div>
      </footer>
    </div>
  );
}
