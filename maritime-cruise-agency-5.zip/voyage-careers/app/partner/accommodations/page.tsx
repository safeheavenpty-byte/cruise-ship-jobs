"use client";

import { useEffect, useState } from "react";
import { createClient } from "@/lib/supabase/client";
import type { Accommodation } from "@/types/database";

const C = { surface: "#FFFFFF", gold: "#A97C50", paper: "#0B2942", paperDim: "#5B7286", hairline: "#E3DCC9", ok: "#4F8B6E" };

export default function PartnerAccommodationsPage() {
  const supabase = createClient();
  const [listings, setListings] = useState<Accommodation[]>([]);
  const [loading, setLoading] = useState(true);

  function photoUrl(path: string) {
    return supabase.storage.from("accommodation-photos").getPublicUrl(path).data.publicUrl;
  }

  useEffect(() => {
    (async () => {
      const { data } = await supabase.from("accommodations").select("*").order("created_at", { ascending: false });
      setListings((data ?? []) as Accommodation[]);
      setLoading(false);
    })();
  }, []);

  return (
    <div>
      <p className="text-xs mb-1" style={{ color: C.gold, fontFamily: "monospace" }}>ACCOMMODATION CATALOG</p>
      <h1 className="text-3xl mb-2" style={{ color: C.paper, fontFamily: "serif" }}>Places available for booking</h1>
      <p className="text-xs mb-8" style={{ color: C.paperDim }}>
        Managed by the Maritime Cruise Agency team — shown here for your reference.
      </p>

      {loading ? (
        <p className="text-sm" style={{ color: C.paperDim }}>Loading…</p>
      ) : listings.length === 0 ? (
        <p className="text-sm" style={{ color: C.paperDim }}>No listings posted yet.</p>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {listings.map((listing) => (
            <div key={listing.id} className="rounded-xl overflow-hidden" style={{ background: C.surface, border: `1px solid ${C.hairline}` }}>
              {listing.photo_paths.length > 0 && (
                <div className="grid grid-cols-3 gap-0.5">
                  {listing.photo_paths.slice(0, 3).map((p) => (
                    <img key={p} src={photoUrl(p)} alt={listing.title} className="w-full h-24 object-cover" />
                  ))}
                </div>
              )}
              <div className="p-4">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-sm" style={{ color: C.paper }}>{listing.title}</p>
                    <p className="text-xs mt-0.5" style={{ color: C.paperDim }}>{listing.location}</p>
                  </div>
                  <span
                    className="text-xs font-semibold px-3 py-1.5 rounded-full shrink-0"
                    style={{ background: listing.is_available ? C.ok : C.hairline, color: listing.is_available ? "#0B2942" : C.paperDim }}
                  >
                    {listing.is_available ? "Available" : "Unavailable"}
                  </span>
                </div>
                {listing.description && <p className="text-xs mt-2" style={{ color: C.paperDim }}>{listing.description}</p>}
                {listing.price_info && <p className="text-xs mt-2" style={{ color: C.gold }}>{listing.price_info}</p>}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
