import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import ScamNotice from "@/components/ScamNotice";

const C = { surface: "#FFFFFF", gold: "#A97C50", paper: "#0B2942", paperDim: "#5B7286", hairline: "#E3DCC9" };

export default async function PartnerOverview() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  const { data: jobs } = await supabase.from("jobs").select("id, is_open").eq("partner_id", user!.id);
  const jobIds = (jobs ?? []).map((j) => j.id);
  const openCount = (jobs ?? []).filter((j) => j.is_open).length;

  const { count: applicantCount } = jobIds.length
    ? await supabase.from("applications").select("*", { count: "exact", head: true }).in("job_id", jobIds)
    : { count: 0 };

  return (
    <div>
      <p className="text-xs mb-1" style={{ color: C.gold, fontFamily: "monospace" }}>PARTNER PORTAL</p>
      <h1 className="text-3xl mb-4" style={{ color: C.paper, fontFamily: "serif" }}>Your postings at a glance</h1>

      <div className="mb-8"><ScamNotice compact /></div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Link href="/partner/jobs" className="rounded-xl p-5 block" style={{ background: C.surface, border: `1px solid ${C.hairline}` }}>
          <div className="text-3xl mb-2" style={{ color: C.paper, fontFamily: "serif" }}>{openCount}</div>
          <div className="text-xs" style={{ color: C.paperDim }}>Open positions</div>
        </Link>
        <Link href="/partner/jobs" className="rounded-xl p-5 block" style={{ background: C.surface, border: `1px solid ${C.hairline}` }}>
          <div className="text-3xl mb-2" style={{ color: C.paper, fontFamily: "serif" }}>{jobs?.length ?? 0}</div>
          <div className="text-xs" style={{ color: C.paperDim }}>Total postings</div>
        </Link>
        <Link href="/partner/applicants" className="rounded-xl p-5 block" style={{ background: C.surface, border: `1px solid ${C.hairline}` }}>
          <div className="text-3xl mb-2" style={{ color: C.paper, fontFamily: "serif" }}>{applicantCount ?? 0}</div>
          <div className="text-xs" style={{ color: C.paperDim }}>Total applicants</div>
        </Link>
      </div>
    </div>
  );
}
