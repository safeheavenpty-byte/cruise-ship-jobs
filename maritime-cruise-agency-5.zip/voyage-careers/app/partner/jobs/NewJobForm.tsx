"use client";

import { useState, useTransition } from "react";
import { createJob } from "@/lib/actions/partner";
import type { JobCategory } from "@/types/database";

const C = { ink: "#F7F4EC", surface: "#FBF8F1", gold: "#A97C50", paper: "#0B2942", paperDim: "#5B7286", hairline: "#E3DCC9" };

export default function NewJobForm({ onCreated }: { onCreated: () => void }) {
  const [open, setOpen] = useState(false);
  const [category, setCategory] = useState<JobCategory>("hospitality");
  const [title, setTitle] = useState("");
  const [line, setLine] = useState("");
  const [contractLength, setContractLength] = useState("");
  const [requirementsText, setRequirementsText] = useState("");
  const [isPending, startTransition] = useTransition();

  function submit(e: React.FormEvent) {
    e.preventDefault();
    startTransition(async () => {
      await createJob({
        category,
        title,
        line,
        contract_length: contractLength,
        requirements: requirementsText.split("\n").map((r) => r.trim()).filter(Boolean),
      });
      setTitle(""); setLine(""); setContractLength(""); setRequirementsText("");
      setOpen(false);
      onCreated();
    });
  }

  if (!open) {
    return (
      <button
        onClick={() => setOpen(true)}
        className="text-xs font-semibold px-4 py-2 rounded-full mb-6"
        style={{ background: C.gold, color: "#0B2942" }}
      >
        + Post a new job
      </button>
    );
  }

  return (
    <form onSubmit={submit} className="rounded-xl p-5 mb-6 space-y-3" style={{ background: C.surface, border: `1px solid ${C.hairline}` }}>
      <select
        value={category}
        onChange={(e) => setCategory(e.target.value as JobCategory)}
        className="w-full px-3 py-2 rounded-lg text-sm"
        style={{ background: C.ink, color: C.paper, border: `1px solid ${C.hairline}` }}
      >
        <option value="cruise">Cruise Ship</option>
        <option value="hospitality">Hospitality</option>
        <option value="healthcare">Healthcare</option>
      </select>
      <input
        placeholder="Job title (e.g. Front Desk Agent)"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        required
        className="w-full px-3 py-2 rounded-lg text-sm"
        style={{ background: C.ink, color: C.paper, border: `1px solid ${C.hairline}` }}
      />
      <input
        placeholder="Company / line name"
        value={line}
        onChange={(e) => setLine(e.target.value)}
        required
        className="w-full px-3 py-2 rounded-lg text-sm"
        style={{ background: C.ink, color: C.paper, border: `1px solid ${C.hairline}` }}
      />
      <input
        placeholder="Contract length (e.g. 2-year work visa)"
        value={contractLength}
        onChange={(e) => setContractLength(e.target.value)}
        className="w-full px-3 py-2 rounded-lg text-sm"
        style={{ background: C.ink, color: C.paper, border: `1px solid ${C.hairline}` }}
      />
      <textarea
        placeholder={"One requirement per line, e.g.\nValid passport\n2+ years experience"}
        value={requirementsText}
        onChange={(e) => setRequirementsText(e.target.value)}
        rows={4}
        className="w-full px-3 py-2 rounded-lg text-sm"
        style={{ background: C.ink, color: C.paper, border: `1px solid ${C.hairline}` }}
      />
      <div className="flex gap-2">
        <button
          type="submit"
          disabled={isPending}
          className="text-xs font-semibold px-4 py-2 rounded-full disabled:opacity-50"
          style={{ background: C.gold, color: "#0B2942" }}
        >
          {isPending ? "Posting…" : "Post job"}
        </button>
        <button type="button" onClick={() => setOpen(false)} className="text-xs px-4 py-2" style={{ color: C.paperDim }}>
          Cancel
        </button>
      </div>
    </form>
  );
}
