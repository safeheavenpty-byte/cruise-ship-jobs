"use client";

import { useEffect, useState, useTransition } from "react";
import { createClient } from "@/lib/supabase/client";
import { toggleJobOpen } from "@/lib/actions/partner";
import NewJobForm from "./NewJobForm";
import type { Job } from "@/types/database";

const C = { surface: "#FFFFFF", gold: "#A97C50", paper: "#0B2942", paperDim: "#5B7286", hairline: "#E3DCC9", ok: "#4F8B6E" };

export default function PartnerJobsPage() {
  const supabase = createClient();
  const [jobs, setJobs] = useState<Job[]>([]);
  const [loading, setLoading] = useState(true);
  const [, startTransition] = useTransition();

  async function load() {
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) return;
    const { data } = await supabase.from("jobs").select("*").eq("partner_id", user.id).order("created_at", { ascending: false });
    setJobs((data ?? []) as Job[]);
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  function toggle(job: Job) {
    startTransition(async () => {
      await toggleJobOpen(job.id, !job.is_open);
      await load();
    });
  }

  return (
    <div>
      <p className="text-xs mb-1" style={{ color: C.gold, fontFamily: "monospace" }}>JOB POSTINGS</p>
      <h1 className="text-3xl mb-6" style={{ color: C.paper, fontFamily: "serif" }}>Manage your listings</h1>

      <NewJobForm onCreated={load} />

      {loading ? (
        <p className="text-sm" style={{ color: C.paperDim }}>Loading…</p>
      ) : jobs.length === 0 ? (
        <p className="text-sm" style={{ color: C.paperDim }}>You haven't posted any jobs yet.</p>
      ) : (
        <div className="space-y-3">
          {jobs.map((job) => (
            <div key={job.id} className="rounded-xl p-4 flex items-center justify-between gap-4 flex-wrap" style={{ background: C.surface, border: `1px solid ${C.hairline}` }}>
              <div>
                <p className="text-sm" style={{ color: C.paper }}>{job.title}</p>
                <p className="text-xs mt-0.5 capitalize" style={{ color: C.paperDim }}>{job.category} · {job.line}</p>
              </div>
              <button
                onClick={() => toggle(job)}
                className="text-xs font-semibold px-3 py-1.5 rounded-full"
                style={{ background: job.is_open ? C.ok : C.hairline, color: job.is_open ? "#0B2942" : C.paperDim }}
              >
                {job.is_open ? "Open" : "Closed"}
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
