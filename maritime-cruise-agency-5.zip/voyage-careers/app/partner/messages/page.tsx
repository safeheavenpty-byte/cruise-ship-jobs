"use client";

import { useEffect, useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { submitInquiry } from "@/lib/actions/inquiries";
import ScamNotice from "@/components/ScamNotice";
import type { Inquiry } from "@/types/database";

const C = { surface: "#FFFFFF", gold: "#A97C50", paper: "#0B2942", paperDim: "#5B7286", hairline: "#E3DCC9", ok: "#4F8B6E" };

const STATUS_LABEL: Record<string, string> = { new: "Sent", in_progress: "Being reviewed", resolved: "Resolved" };

export default function PartnerMessagesPage() {
  const supabase = createClient();
  const [threads, setThreads] = useState<Inquiry[]>([]);
  const [message, setMessage] = useState("");
  const [sending, setSending] = useState(false);
  const [profile, setProfile] = useState<{ name: string; email: string } | null>(null);

  async function load() {
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) return;

    const [{ data: rows }, { data: prof }] = await Promise.all([
      supabase.from("inquiries").select("*").eq("sender_id", user.id).order("created_at", { ascending: false }),
      supabase.from("profiles").select("full_name, partner_company").eq("id", user.id).single(),
    ]);
    setThreads((rows ?? []) as Inquiry[]);
    setProfile({ name: prof?.full_name ?? prof?.partner_company ?? "Partner", email: user.email ?? "" });
  }

  useEffect(() => { load(); }, []);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!profile) return;
    setSending(true);
    await submitInquiry({ name: profile.name, email: profile.email, message });
    setMessage("");
    await load();
    setSending(false);
  }

  return (
    <div>
      <p className="text-xs mb-1" style={{ color: C.gold, fontFamily: "monospace" }}>MESSAGES</p>
      <h1 className="text-3xl mb-2" style={{ color: C.paper, fontFamily: "serif" }}>Talk to our team</h1>
      <p className="text-xs mb-6" style={{ color: C.paperDim }}>
        Questions about postings, applicants, or anything else — reach us here directly.
      </p>

      <div className="mb-6"><ScamNotice compact /></div>

      <form onSubmit={submit} className="rounded-xl p-5 mb-8 space-y-3" style={{ background: C.surface, border: `1px solid ${C.hairline}` }}>
        <textarea
          placeholder="Ask us anything…"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          required
          rows={3}
          className="w-full px-3 py-2 rounded-lg text-sm"
          style={{ background: "#FFFFFF", color: C.paper, border: `1px solid ${C.hairline}` }}
        />
        <button
          type="submit"
          disabled={sending || !message}
          className="text-xs font-semibold px-4 py-2 rounded-full disabled:opacity-50"
          style={{ background: C.gold, color: "#0B2942" }}
        >
          {sending ? "Sending…" : "Send message"}
        </button>
      </form>

      {threads.length === 0 ? (
        <p className="text-sm" style={{ color: C.paperDim }}>No messages yet.</p>
      ) : (
        <div className="space-y-4">
          {threads.map((t) => (
            <div key={t.id} className="rounded-xl p-4" style={{ background: C.surface, border: `1px solid ${C.hairline}` }}>
              <div className="flex justify-between items-start mb-2">
                <span className="text-xs" style={{ color: C.paperDim }}>{new Date(t.created_at).toLocaleString()}</span>
                <span
                  className="text-xs font-semibold px-2.5 py-1 rounded-full"
                  style={{ background: t.status === "resolved" ? C.ok : "#FFFFFF", color: t.status === "resolved" ? "#0B2942" : C.gold, border: t.status === "resolved" ? "none" : `1px solid ${C.hairline}` }}
                >
                  {STATUS_LABEL[t.status]}
                </span>
              </div>
              <p className="text-sm" style={{ color: C.paper }}>{t.message}</p>
              {t.staff_reply && (
                <div className="mt-3 pt-3" style={{ borderTop: `1px solid ${C.hairline}` }}>
                  <p className="text-xs mb-1" style={{ color: C.gold }}>Maritime Cruise Agency team</p>
                  <p className="text-sm" style={{ color: C.paperDim }}>{t.staff_reply}</p>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
