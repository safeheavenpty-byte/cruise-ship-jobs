import { redirect } from "next/navigation";
import Link from "next/link";
import { getProfile } from "@/lib/supabase/server";

const C = { bg: "#F7F4EC", navy: "#0B2942", wood: "#A97C50", light: "#B7C4D1" };

const NAV = [
  { href: "/partner", label: "Overview" },
  { href: "/partner/jobs", label: "Job Postings" },
  { href: "/partner/applicants", label: "Applicants" },
  { href: "/partner/accommodations", label: "Accommodations" },
  { href: "/partner/messages", label: "Messages" },
];

export default async function PartnerLayout({ children }: { children: React.ReactNode }) {
  const profile = await getProfile();
  if (!profile || profile.role !== "partner") redirect("/login");

  return (
    <div className="min-h-screen flex" style={{ background: C.bg }}>
      <aside className="w-60 shrink-0 hidden md:flex flex-col" style={{ background: C.navy }}>
        <div className="px-6 py-6" style={{ borderBottom: "1px solid rgba(255,255,255,0.1)" }}>
          <p className="text-sm" style={{ color: C.wood, fontFamily: "serif" }}>Maritime Cruise Agency</p>
          <p className="text-xs mt-0.5" style={{ color: C.light }}>{profile.partner_company ?? "Partner"}</p>
        </div>
        <nav className="flex-1 px-3 py-4 space-y-1">
          {NAV.map((item) => (
            <Link key={item.href} href={item.href} className="block px-3 py-2.5 rounded-lg text-sm" style={{ color: C.light }}>
              {item.label}
            </Link>
          ))}
        </nav>
      </aside>
      <main className="flex-1 p-6 md:p-10 max-w-4xl mx-auto w-full">{children}</main>
    </div>
  );
}
