import { createClient } from "@/lib/supabase/server";

const C = { surface: "#FFFFFF", gold: "#A97C50", paper: "#0B2942", paperDim: "#5B7286", hairline: "#E3DCC9", ok: "#4F8B6E" };

const STAGE_LABEL: Record<string, string> = {
  submitted: "Submitted",
  exam_pending: "Exam pending",
  documents_pending: "Documents pending",
  under_review: "Under review",
  approved: "Approved",
  rejected: "Rejected",
};

export default async function PartnerApplicantsPage() {
  const supabase = await createClient();

  // RLS ("partner sees applicants to their jobs") scopes this to only
  // applications for jobs this partner posted — no extra filtering needed
  // here beyond the join for display.
  const { data: applications } = await supabase
    .from("applications")
    .select("id, stage, created_at, profiles:applicant_id (full_name), jobs:job_id (title, category)")
    .order("created_at", { ascending: false });

  return (
    <div>
      <p className="text-xs mb-1" style={{ color: C.gold, fontFamily: "monospace" }}>APPLICANTS</p>
      <h1 className="text-3xl mb-2" style={{ color: C.paper, fontFamily: "serif" }}>Applicants to your postings</h1>
      <p className="text-xs mb-8" style={{ color: C.paperDim }}>
        Exam results and document approvals are managed by the Maritime Cruise Agency review team.
      </p>

      {!applications || applications.length === 0 ? (
        <p className="text-sm" style={{ color: C.paperDim }}>No applicants yet.</p>
      ) : (
        <div className="space-y-3">
          {applications.map((a: any) => (
            <div
              key={a.id}
              className="rounded-xl p-4 flex items-center justify-between gap-4 flex-wrap"
              style={{ background: C.surface, border: `1px solid ${C.hairline}` }}
            >
              <div>
                <p className="text-sm" style={{ color: C.paper }}>{a.profiles?.full_name ?? "Unknown applicant"}</p>
                <p className="text-xs mt-0.5" style={{ color: C.paperDim }}>{a.jobs?.title ?? "Unknown role"}</p>
              </div>
              <span
                className="text-xs font-semibold px-3 py-1.5 rounded-full"
                style={{
                  background: a.stage === "approved" ? C.ok : "#FFFFFF",
                  color: a.stage === "approved" ? "#0B2942" : C.gold,
                  border: a.stage === "approved" ? "none" : `1px solid ${C.hairline}`,
                }}
              >
                {STAGE_LABEL[a.stage] ?? a.stage}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
